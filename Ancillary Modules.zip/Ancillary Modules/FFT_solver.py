

##############################
import numpy as np
##############################
import matplotlib.pyplot as plt
##############################
import matplotlib.image as mpimg
##############################
import pandas as pd
##############################


################################################################################
#    the following has been set up as a recursive function which means         #
#    it calls itself during its own definition - this means that it will       #
#   continue to loop in its execution with each output being a novel input     #
#              until the predefined base case has been reached                 #
################################################################################


################################################################################
#     all credit for the core content goes to James Cooley and John Tukey      #
#   of MIT in 1965 - doi.org/10.2307/2003354 - "An Algorithm for the Machine   #
# Calculation of Complex Fourier Series" - these guys are kings of their time. #
#                                                                              #
#   They reduced the computational complexity from: "N^2" to "N*log_2(N)".     #
#                                                                              #
#  N is the number of samples. As an example, when N = 1,000,000, the former   #
#  requires 50 176 times more computations - i.e., takes 50 176 times longer   #
#     [assuming fixed time per computation independent of computation type     #
#                               or chain length].                              #
#                                                                              #
#          This is what puts the "Fast" in "Fast Fourier Transform".           #
#                                                                              #
#     Crucially, the FFT is still a Discrete Fourier Transform - it's just     #
#  an extremely efficient one [think Taguchi, but for categorising the         #
#                      underlying geometry of a signal].                       #
#                                                                              #
#    the N^2 type is what is known as a naive DFT - naive because it's         #
#                   computationally unnecessarily expensive.                   #
################################################################################


################################################################################
#      the following function is recursive - coming from  a MATLAB background  #
#    this can take some getting used to...the central idea here is that the    #
# function calls itself during its own definition; that this DOESN'T violate   #
#        that definition but is meaningfully interpreted by the computer.      #
#                                                                              #
#    Functionally, what this means is that the problem set is divided and      #
#    cascades into itself until it reaches the base case - where it can't be   #
#    divided any further. Typically, this is where the script outputs the      #
#    answer - however, in the case of the cooley-tukey FFT - what happens is   #
# that each of the newly distinct FFTs recombine to form - using the symmetry  #
#      of the Euler circle - to compute the full set of frequency amplitudes   #
################################################################################

def FFT_function(x) :                       #vector of time domain amplitudes as initial input

    N = len(x)                              #current number of samples

    if N == 1 :                             #base case reached; recursion terminates

        return x

    else:
        
        set_A = FFT_function(x[::2])    #start at index 0, go to the end, and take every 2nd element       
        
        set_B = FFT_function(x[1::2])   #start at index 1, go to the end, and take every 2nd element       

        twiddle_factor = np.exp(-2j*np.pi*np.arange(N)/N)

        X = np.concatenate([set_A + (twiddle_factor[:N // 2] * set_B), \
                            set_A - (twiddle_factor[:N // 2] * set_B)])

        return X
    
################################################################################







