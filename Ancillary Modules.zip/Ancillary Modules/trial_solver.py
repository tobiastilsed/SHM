

# =====================
import numpy as np
# =====================

def trial_function(excitation_frequency) :

# ===============================================================

    if excitation_frequency == 5 :
        
        # =====================
        #        HEALTHY:
        # =====================

        trial_1 = np.loadtxt('T1.txt')
        trial_2 = np.loadtxt('U1.txt')
        trial_3 = np.loadtxt('U6.txt')
        trial_4 = np.loadtxt('U11.txt')
        trial_5 = np.loadtxt('U16.txt')
        trial_6 = np.loadtxt('U21.txt')

        # =====================
        #        DAMAGED:
        # =====================

        L1 = np.loadtxt('T6.txt')
        L2 = np.loadtxt('T11.txt')
        L3 = np.loadtxt('T16.txt')
        L4 = np.loadtxt('T21.txt')
        L5 = np.loadtxt('T26.txt')

        print("\n-----------------------------\n")        
        print("   Healthy Sets Imported:")
        print("\n  T1  U1  U6  U11  U16  U21")
        print("\n-----------------------------\n") 
        print("   Damaged Sets Imported:")
        print("\n    T6  T11  T16  T21  T26")
        print("\n-----------------------------\n") 

# ===============================================================

    if excitation_frequency == 10 :
        
        # =====================
        #        HEALTHY:
        # =====================
        
        trial_1 = np.loadtxt('T2.txt')
        trial_2 = np.loadtxt('U2.txt')
        trial_3 = np.loadtxt('U7.txt')
        trial_4 = np.loadtxt('U12.txt')
        trial_5 = np.loadtxt('U17.txt')
        trial_6 = np.loadtxt('U22.txt')
        
        # =====================
        #        DAMAGED:
        # =====================
        
        L1 = np.loadtxt('T7.txt')
        L2 = np.loadtxt('T12.txt')
        L3 = np.loadtxt('T17.txt')
        L4 = np.loadtxt('T22.txt')
        L5 = np.loadtxt('T27.txt')

        print("\n-----------------------------\n")        
        print("   Healthy Sets Imported:")
        print("\n  T2  U2  U7  U12  U17  U22")
        print("\n-----------------------------\n") 
        print("   Damaged Sets Imported:")
        print("\n    T7  T12  T17  T22  T27")
        print("\n-----------------------------\n") 

# ===============================================================

    if excitation_frequency == 15 :
        
        # =====================
        #        HEALTHY:
        # =====================
        
        trial_1 = np.loadtxt('T3.txt')
        trial_2 = np.loadtxt('U3.txt')
        trial_3 = np.loadtxt('U8.txt')
        trial_4 = np.loadtxt('U13.txt')
        trial_5 = np.loadtxt('U18.txt')
        trial_6 = np.loadtxt('U23.txt')
        
        # =====================
        #        DAMAGED:
        # =====================
        
        L1 = np.loadtxt('T8.txt')
        L2 = np.loadtxt('T13.txt')
        L3 = np.loadtxt('T18.txt')
        L4 = np.loadtxt('T23.txt')
        L5 = np.loadtxt('T28.txt')

        print("\n-----------------------------\n")        
        print("   Healthy Sets Imported:")
        print("\n  T3  U3  U8  U13  U18  U23")
        print("\n-----------------------------\n") 
        print("   Damaged Sets Imported:")
        print("\n    T8  T13  T18  T23  T28")
        print("\n-----------------------------\n") 

# ===============================================================

    if excitation_frequency == 20 :
        
        # =====================
        #        HEALTHY:
        # =====================
        
        trial_1 = np.loadtxt('T4.txt')
        trial_2 = np.loadtxt('U4.txt')
        trial_3 = np.loadtxt('U9.txt')
        trial_4 = np.loadtxt('U14.txt')
        trial_5 = np.loadtxt('U19.txt')
        trial_6 = np.loadtxt('U24.txt')
        
        # =====================
        #        DAMAGED:
        # =====================
        
        L1 = np.loadtxt('T9.txt')
        L2 = np.loadtxt('T14.txt')
        L3 = np.loadtxt('T19.txt')
        L4 = np.loadtxt('T24.txt')
        L5 = np.loadtxt('T29.txt')

        print("\n-----------------------------\n")        
        print("   Healthy Sets Imported:")
        print("\n  T4  U4  U9  U14  U19  U24")
        print("\n-----------------------------\n") 
        print("   Damaged Sets Imported:")
        print("\n    T9  T14  T19  T24  T29")
        print("\n-----------------------------\n") 

# ===============================================================

    if excitation_frequency == 25 :
        
        # =====================
        #        HEALTHY:
        # =====================
        
        trial_1 = np.loadtxt('T5.txt')
        trial_2 = np.loadtxt('U5.txt')
        trial_3 = np.loadtxt('U10.txt')
        trial_4 = np.loadtxt('U15.txt')
        trial_5 = np.loadtxt('U20.txt')
        trial_6 = np.loadtxt('U25.txt')
        
        # =====================
        #        DAMAGED:
        # =====================
        
        L1 = np.loadtxt('T10.txt')
        L2 = np.loadtxt('T15.txt')
        L3 = np.loadtxt('T20.txt')
        L4 = np.loadtxt('T25.txt')
        L5 = np.loadtxt('T30.txt')

        print("\n-----------------------------\n")        
        print("   Healthy Sets Imported:")
        print("\n  T5  U5  U10  U15  U20  U25")
        print("\n-----------------------------\n") 
        print("   Damaged Sets Imported:")
        print("\n    T10  T15  T20  T25  T30")
        print("\n-----------------------------\n") 

# ===============================================================

    return trial_1, trial_2, trial_3, trial_4, trial_5, trial_6, L1, L2, L3, L4, L5


