

# =====================
import numpy as np
# =====================
from scipy.optimize import curve_fit
# =====================
import matplotlib.pyplot as plt
# =====================
import matplotlib.image as mpimg
# =====================
from trial_solver import trial_function
# =====================


# ==========================================
#   MODULATE THE THREE BELOW - EVERYTHING  =
#            ELSE IS AUTOMATED:            =
# ==========================================

excitation_frequency = 10    # (Hz)

# =====================

accelerometer_channel = 2   # 2 = Nacelle
                            # 3 = Landing Platform

# =====================

damage_index = 6             # L1 = 6; L2 = 7...

# ==========================================

img = mpimg.imread('test matrices.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('moment_3_time.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

trial_1, trial_2, trial_3, trial_4, trial_5, trial_6, L1, L2, L3, L4, L5 = trial_function(excitation_frequency)      #don't mind me    

# =====================

x_full = np.zeros([25000, 11])

# =====================

column_index = accelerometer_channel

# =====================

x_full[:, 0]  = trial_1[:, column_index]
x_full[:, 1]  = trial_2[:, column_index]
x_full[:, 2]  = trial_3[:, column_index]
x_full[:, 3]  = trial_4[:, column_index]
x_full[:, 4]  = trial_5[:, column_index]
x_full[:, 5]  = trial_6[:, column_index]
x_full[:, 6]  =      L1[:, column_index]
x_full[:, 7]  =      L2[:, column_index]
x_full[:, 8]  =      L3[:, column_index]
x_full[:, 9]  =      L4[:, column_index]
x_full[:, 10] =      L5[:, column_index]

# =====================

x_full_sync = np.zeros([25000, 11])

# =====================

x_full_sync[:, 0]  = trial_1[:, 3]
x_full_sync[:, 1]  = trial_2[:, 3]
x_full_sync[:, 2]  = trial_3[:, 3]
x_full_sync[:, 3]  = trial_4[:, 3]
x_full_sync[:, 4]  = trial_5[:, 3]
x_full_sync[:, 5]  = trial_6[:, 3]
x_full_sync[:, 6]  =      L1[:, 3]
x_full_sync[:, 7]  =      L2[:, 3]
x_full_sync[:, 8]  =      L3[:, 3]
x_full_sync[:, 9]  =      L4[:, 3]
x_full_sync[:, 10] =      L5[:, 3]

# =====================

if column_index == 2 :
    
    location_tag = "Nacelle"
    
if column_index == 3 :
    
    location_tag = "Landing Platform"

# =====================

if damage_index == 6 :
    
    damage_level_tag = "L1"

if damage_index == 7 :
    
    damage_level_tag = "L2"

if damage_index == 8 :
    
    damage_level_tag = "L3"
    
if damage_index == 9 :
    
    damage_level_tag = "L4"
    
if damage_index == 10 :
    
    damage_level_tag = "L5"

# =========================================================
# ================= CHECKING DIVISIBILITY: ================
# =========================================================

if 5000 % excitation_frequency != 0 :
    
    remainder = round(((5000 % excitation_frequency) / excitation_frequency)**-1) - 1

    print("The sample rate and excitation")
    print("frequency aren't playing nice ")
    print("together - we're going to have")
    print("to skip:                      ")
    print("                              ")
    print("          %.0f cycles" % remainder)
    print("                              ")
    print(" ...between each visualised"   )
    print("  and evaluated cycle for"     )
    print("      proper alignment."       )
    print("\n-----------------------------\n")
    
else :
        
    remainder = 0

# =========================================================
# =================== ALIGNING THE SETS ===================
# =========================================================

full = 5000 // (1 * excitation_frequency)

full_float = 5000 / excitation_frequency

# =====================

necessary_cycles = round((remainder + 1) * 10 * full_float)

# =====================

half = 5000 // (2 * excitation_frequency)

half_float = 5000 / (2 * excitation_frequency)

# =====================

three_quarter = (3 * 5000) // (4 * excitation_frequency)
  
three_quarter_float = (3 * 5000) / (4 * excitation_frequency)

# =====================

x_aligned_full = np.zeros([necessary_cycles, 11])

sin_aligned_full = np.zeros([necessary_cycles, 11])

# =========================================================
# ============ TEMPORAL ALIGNMENT FOR LOOP: ===============
# =========================================================

for trial_index in range (11) :

    # =====================
    
    x_local_sync = x_full_sync[:, trial_index]
    
    x_local = x_full[:, trial_index]

    # =====================
    
    t = np.arange(0, 5, 0.0002)  

    # ==========================================
    # ============ fitting function: ===========
    # ==========================================
    
    t_fitted = t
    
    y = x_local_sync
    
    # =====================
    
    initial_guess = [1.3, excitation_frequency, 0.0, 0.0]
    
    # =====================
    
    def sine_func(t_fitted, A, f, phi, offset) :
        
        return A * np.sin(2 * np.pi * f * t_fitted + phi) + offset

    # =====================
    
    params, _ = curve_fit(sine_func, t_fitted, y, p0=initial_guess)
    
    A_fit, f_fit, phi_fit, offset_fit = params
    
    x_fitted = sine_func(t_fitted, A_fit, f_fit, phi_fit, offset_fit)
    
    # =====================
    
    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.plot(t_fitted, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

    # ==========================================
    # ============= ascending case =============
    # ==========================================
    
    if x_fitted[1] > x_fitted[0] :         
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # ==========================================
    # ============ descending case =============
    # ==========================================
    
    elif x_fitted[1] < x_fitted[0] :
        
        x_local = x_local[half:]
        
        x_fitted = x_fitted[half:]
        
    # =====================
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # =====================
    
    C = counter_1 + three_quarter         #preferred this location aesthetically
    
    # =====================
    
    x_local = x_local[C:]                 #slicing from preferred location
    
    x_fitted = x_fitted[C:]               #slicing from preferred location
    
    # =====================
    
    x_local = x_local[:necessary_cycles]                #slicing up to ten cycles [or that which facilitates a coherent mapping of ten]
    
    x_fitted = x_fitted[:necessary_cycles]              #slicing up to ten cycles [or that which facilitates a coherent mapping of ten]
    
    # =====================

    x_aligned_full[:, trial_index] = x_local
    
    sin_aligned_full[:, trial_index] = x_fitted
    
    t = t[:necessary_cycles]                            

    # =====================

    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

# =========================================================
# =================== SLICING THE SETS: ===================
# =========================================================

t = t[:full]

# =====================

trial_1_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_1_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 0]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1


# =====================

trial_2_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_2_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 1]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

trial_3_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_3_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 2]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

trial_4_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_4_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 3]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

trial_5_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_5_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 4]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

trial_6_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_6_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 5]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L1_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L1_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 6]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L2_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L2_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 7]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L3_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L3_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 8]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L4_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L4_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 9]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L5_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L5_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 10]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, trial_1_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_2_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_3_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_4_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_5_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_6_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L1_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L2_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L3_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L4_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L5_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.show()

# =========================================================
# ================= STATISTICAL ANALYSIS: =================
# =========================================================

statistical_baseline = np.column_stack(( trial_1_sliced, \
                                         trial_2_sliced, \
                                         trial_3_sliced, \
                                         trial_4_sliced, \
                                         trial_5_sliced, \
                                         trial_6_sliced    ))

# =========================================================

mean_vector = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector[row, 0] = np.sum(statistical_baseline[row, :])/60
    
    row = row + 1

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, statistical_baseline, 'b', alpha = 0.15, linewidth = 0.05)
#plt.plot(t, mean_vector, 'b', alpha = 0.8, linewidth = 0.3)
#plt.show()

# =========================================================

sigma_vector = np.zeros([full, 1])

# =====================

time_bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc_1 = np.zeros([60, 1])
    
    row = 0
    
    mean = mean_vector[time_bin_index]
    
    for evaluation_number_1 in range (60) :
        
        sub_calc_1[row, 0] = (statistical_baseline[time_bin_index, row] - mean[0])**2
        
        row = row + 1
    
    sigma_vector[time_bin_index, 0] = np.sqrt(np.sum(sub_calc_1) / 60)
    
    time_bin_index = time_bin_index + 1

# =====================

contour_upper = mean_vector + sigma_vector    # 2 dimensional

contour_lower = mean_vector - sigma_vector    # 2 dimensional

# =====================

contour_lower = contour_lower.flatten()       # 1 dimensional

contour_upper = contour_upper.flatten()       # 1 dimensional

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, statistical_baseline, 'b', alpha = 0.2, linewidth = 0.05)
#plt.fill_between(t, contour_lower, contour_upper, color = 'gray', alpha = 0.3, edgecolor = 'none')
#plt.plot(t, mean_vector, color = 'b', alpha = 0.8, linewidth = 0.2)
#plt.plot(t, contour_upper, color = 'b', alpha = 0.8, linewidth = 0.2, linestyle = '--')
#plt.plot(t, contour_lower, color = 'b', alpha = 0.8, linewidth = 0.2, linestyle = '--')
#plt.plot(t, L1_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.show()

# =========================================================

gamma_1_vector_trial_1 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((trial_1_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_trial_1[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_trial_2 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((trial_2_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_trial_2[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_trial_3 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((trial_3_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_trial_3[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_trial_4 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((trial_4_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_trial_4[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_trial_5 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((trial_5_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_trial_5[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_trial_6 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((trial_6_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_trial_6[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1
    
# =====================

plt.figure(figsize = (25, 6), dpi = 300)
plt.title('Skewness - Trial 1')
plt.plot(t, gamma_1_vector_trial_1, 'b', alpha = 0.8, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'b', alpha = 0.1, linewidth = 0.5)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =====================

plt.figure(figsize = (25, 6), dpi = 300)
plt.title('Skewness - Trial 2')
plt.plot(t, gamma_1_vector_trial_1, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'b', alpha = 0.8, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'b', alpha = 0.1, linewidth = 0.5)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =====================

plt.figure(figsize = (25, 6), dpi = 300)
plt.title('Skewness - Trial 3')
plt.plot(t, gamma_1_vector_trial_1, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'b', alpha = 0.8, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'b', alpha = 0.1, linewidth = 0.5)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =====================

plt.figure(figsize = (25, 6), dpi = 300)
plt.title('Skewness - Trial 4')
plt.plot(t, gamma_1_vector_trial_1, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'b', alpha = 0.8, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'b', alpha = 0.1, linewidth = 0.5)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =====================

plt.figure(figsize = (25, 6), dpi = 300)
plt.title('Skewness - Trial 5')
plt.plot(t, gamma_1_vector_trial_1, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'b', alpha = 0.8, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'b', alpha = 0.1, linewidth = 0.5)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =====================

plt.figure(figsize = (25, 6), dpi = 300)
plt.title('Skewness - Trial 6')
plt.plot(t, gamma_1_vector_trial_1, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'b', alpha = 0.1, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'b', alpha = 0.8, linewidth = 0.5)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =====================

gamma_1_vector_L1 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((L1_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_L1[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_L2 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((L2_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_L2[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_L3 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((L3_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_L3[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_L4 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((L4_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_L4[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

gamma_1_vector_L5 = np.zeros([full, 1])

bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc = np.zeros([10, 1])
    
    column = 0

    for evaluation_number_1 in range (10) :
        
        sub_calc[column, 0] = ((L5_sliced[bin_index, column] - mean_vector[bin_index, 0]) / sigma_vector[bin_index, 0])**3
        
        column = column + 1

    gamma_1_vector_L5[bin_index] = np.sum(sub_calc) / 10
    
    bin_index = bin_index + 1

# =====================

if damage_index == 6 :
    
    A = L1_sliced
    
if damage_index == 7 :
    
    A = L2_sliced
    
if damage_index == 8 :
    
    A = L3_sliced
    
if damage_index == 9 :
    
    A = L4_sliced
    
if damage_index == 10 :
    
    A = L5_sliced

# =====================

if damage_index == 6 :
    
    B = gamma_1_vector_L1
    
if damage_index == 7 :
    
    B = gamma_1_vector_L2
    
if damage_index == 8 :
    
    B = gamma_1_vector_L3
    
if damage_index == 9 :
    
    B = gamma_1_vector_L4
    
if damage_index == 10 :
    
    B = gamma_1_vector_L5

# =====================

C = np.column_stack((   gamma_1_vector_trial_1, \
                        gamma_1_vector_trial_2, \
                        gamma_1_vector_trial_3, \
                        gamma_1_vector_trial_4, \
                        gamma_1_vector_trial_5, \
                        gamma_1_vector_trial_6    ))
    
# =========================================================
#         TIME DOMAIN VISUALISATION FOR REFERENCE:
# =========================================================

plt.figure(figsize = (25, 6), dpi = 1200)
plt.fill_between(t, contour_lower, contour_upper, color = 'gray', alpha = 0.2, edgecolor = 'none')
plt.plot(t, mean_vector, color = 'k', alpha = 0.6, linewidth = 0.2)
plt.plot(t, contour_upper, color = 'k', alpha = 0.6, linewidth = 0.2, linestyle = '--')
plt.plot(t, contour_lower, color = 'k', alpha = 0.6, linewidth = 0.2, linestyle = '--')
plt.plot(t, statistical_baseline, 'g', alpha = 0.1, linewidth = 0.1)
plt.plot(t, A, 'r', alpha = 0.4, linewidth = 0.1)
#for x in t :   
#    plt.axvline(x = x, color = 'black', linewidth = 0.2, alpha = 0.4)
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Amplitude (m/s²)', labelpad = 15, fontsize = 11)
plt.show()

# =========================================================
#                    FULL SKEWNESS PLOT:
# =========================================================

plt.figure(figsize = (25, 6), dpi = 1200)
plt.title('Excitation Frequency: %.0f (Hz)                                            Statistical Moment 3 [Skewness] of the Six Healthy Trials [6 x 10 cycles] and a Single Damaged Trial [10 cycles] - Per Bin in the Time Domain                                            Location: %s' % (excitation_frequency, location_tag), fontsize = 11)     #don't mind me...     
plt.plot(t, gamma_1_vector_trial_1, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, B, 'r', alpha = 0.8, linewidth = 0.5)
#plt.plot(t, B, linestyle = 'None', marker = 'o', markerfacecolor = 'none', markeredgecolor = 'y', markeredgewidth = 0.5, markersize = 2.5, alpha = 0.8)
#for x in t :   
#    plt.axvline(x = x, color = 'black', linewidth = 0.2, alpha = 0.4)
plt.plot(0, 0, color ='g', alpha = 0.3, linewidth = 1.0, label = 'Healthy')
plt.plot(0, 0, color ='r', alpha = 0.8, linewidth = 1.0, label = '%s' % (damage_level_tag))
plt.legend(fontsize = 11, loc = 'upper right')
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =========================================================
#                 ZOOMING FOR HEALTHY DETAIL:
# =========================================================

plt.figure(figsize = (25, 6), dpi = 1200)
plt.title('Excitation Frequency: %.0f (Hz)                                            Statistical Moment 3 [Skewness] of the Six Healthy Trials [6 x 10 cycles] and a Single Damaged Trial [10 cycles] - Per Bin in the Time Domain                                            Location: %s' % (excitation_frequency, location_tag), fontsize = 11)     #don't mind me...     
plt.plot(t, gamma_1_vector_trial_1, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_2, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_3, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_4, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_5, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, gamma_1_vector_trial_6, 'g', alpha = 0.3, linewidth = 0.5)
plt.plot(t, B, 'r', alpha = 0.8, linewidth = 0.5)
plt.ylim(2.5*np.min(C), 2.5*np.max(C))
plt.plot(0, 0, color ='g', alpha = 0.3, linewidth = 1.0, label = 'Healthy')
plt.plot(0, 0, color ='r', alpha = 0.8, linewidth = 1.0, label = '%s' % (damage_level_tag))
plt.legend(fontsize = 11, loc = 'upper right')
plt.xlabel('Time (s)', fontsize = 11)
plt.ylabel('Skewness (dimensionless)', labelpad = 15, fontsize = 11)
plt.show()

# =========================================================












