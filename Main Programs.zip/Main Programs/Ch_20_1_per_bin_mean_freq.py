

# =====================
import numpy as np
# =====================
import matplotlib.pyplot as plt
# =====================
import matplotlib.image as mpimg
# =====================
from scipy.optimize import curve_fit
# =====================
from FFT_solver import FFT_function
# =====================
from trial_solver import trial_function
# =====================


# ==========================================
#          MODULATE THE FIVE BELOW         =
# ==========================================
#              THE CRUCIAL TWO:            =
# ==========================================

excitation_frequency = 10    # (Hz)

# =====================

accelerometer_channel = 2   # 2 = Nacelle
                            # 3 = Landing Platform

# ==========================================
#    THE LESS CRUCIAL BUT USEFUL THREE:    =
# ==========================================

damage_index = 6            # L1 = 6; L2 = 7...

lower_bound_detailed = 148   # (Hz)

upper_bound_detailed = 152  # (Hz)

# ==========================================

img = mpimg.imread('test matrices.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('DFT.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('moment_1_time.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

trial_1, trial_2, trial_3, trial_4, trial_5, trial_6, L1, L2, L3, L4, L5 = trial_function(excitation_frequency)      #don't mind me    

# =====================

x_full = np.zeros([25000, 11])

# =====================

column_index = accelerometer_channel

# =====================

x_full[:, 0]  = trial_1[:, column_index]
x_full[:, 1]  = trial_2[:, column_index]
x_full[:, 2]  = trial_3[:, column_index]
x_full[:, 3]  = trial_4[:, column_index]
x_full[:, 4]  = trial_5[:, column_index]
x_full[:, 5]  = trial_6[:, column_index]
x_full[:, 6]  =      L1[:, column_index]
x_full[:, 7]  =      L2[:, column_index]
x_full[:, 8]  =      L3[:, column_index]
x_full[:, 9]  =      L4[:, column_index]
x_full[:, 10] =      L5[:, column_index]

# =====================

x_full_sync = np.zeros([25000, 11])

# =====================

x_full_sync[:, 0]  = trial_1[:, 3]
x_full_sync[:, 1]  = trial_2[:, 3]
x_full_sync[:, 2]  = trial_3[:, 3]
x_full_sync[:, 3]  = trial_4[:, 3]
x_full_sync[:, 4]  = trial_5[:, 3]
x_full_sync[:, 5]  = trial_6[:, 3]
x_full_sync[:, 6]  =      L1[:, 3]
x_full_sync[:, 7]  =      L2[:, 3]
x_full_sync[:, 8]  =      L3[:, 3]
x_full_sync[:, 9]  =      L4[:, 3]
x_full_sync[:, 10] =      L5[:, 3]

# =====================

if column_index == 2 :
    
    location_tag = "Nacelle"
    
if column_index == 3 :
    
    location_tag = "Landing Platform"

# =====================

bin_index_lower = round(lower_bound_detailed / (2500 / 8192))

bin_index_upper = round(upper_bound_detailed / (2500 / 8192))

# =====================

harmonic_lines = np.arange(0, 2500 + excitation_frequency, excitation_frequency)

# =====================

if damage_index == 6 :
    
    damage_level_tag = "L1"

if damage_index == 7 :
    
    damage_level_tag = "L2"

if damage_index == 8 :
    
    damage_level_tag = "L3"
    
if damage_index == 9 :
    
    damage_level_tag = "L4"
    
if damage_index == 10 :
    
    damage_level_tag = "L5"

# =========================================================
# =================== ALIGNING THE SETS ===================
# =========================================================

x_aligned_full = np.zeros([16384, 11])

sin_aligned_full = np.zeros([16384, 11])

# =====================

full = 5000 // (excitation_frequency)

full_float = 5000 / excitation_frequency

# =====================

half = 5000 // (2 * excitation_frequency)

half_float = 5000 / (2 * excitation_frequency)

# =====================

three_quarter = (3 * 5000) // (4 * excitation_frequency)

three_quarter_float = (3 * 5000) / (4 * excitation_frequency)

# =========================================================
# ============ TEMPORAL ALIGNMENT FOR LOOP: ===============
# =========================================================

for trial_index in range (11) :

    # =====================
    
    x_local_sync = x_full_sync[:, trial_index]
    
    x_local = x_full[:, trial_index]
    
    # =====================
    
    t = np.arange(0, 5, 0.0002)  
    
    # ==========================================
    # ============ fitting function: ===========
    # ==========================================
    
    t_fitted = t
    
    y = x_local_sync
    
    # =====================
    
    initial_guess = [1.3, excitation_frequency, 0.0, 0.0]
    
    # =====================
    
    def sine_func(t_fitted, A, f, phi, offset) :
        
        return A * np.sin(2 * np.pi * f * t_fitted + phi) + offset
    
    params, _ = curve_fit(sine_func, t_fitted, y, p0=initial_guess)
    
    A_fit, f_fit, phi_fit, offset_fit = params
    
    x_fitted = sine_func(t_fitted, A_fit, f_fit, phi_fit, offset_fit)
    
    # =====================
    
    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'g', alpha = 0.3, linewidth = 1.0)
    #plt.plot(t, x_fitted, 'b', alpha = 0.3, linewidth = 1.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

    # ==========================================
    # ============= ascending case =============
    # ==========================================
    
    if x_fitted[1] > x_fitted[0] :         
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # ==========================================
    # ============ descending case =============
    # ==========================================
    
    elif x_fitted[1] < x_fitted[0] :
        
        x_local = x_local[half:]
        
        x_fitted = x_fitted[half:]
        
    # =====================
        
        counter_1 = 0
        
        for evaluation_number in range(24000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # =====================
    
    C = counter_1 + three_quarter         #preferred this location aesthetically
    
    # =====================
    
    x_local = x_local[C:]                 #slicing from preferred location
    
    x_fitted = x_fitted[C:]               #slicing from preferred location
    
    # =====================
    
    x_local = x_local[:16384]             #slicing up to 2^k (k = 14)
    
    x_fitted = x_fitted[:16384]           #slicing up to 2^k (k = 14)
    
    # =====================
    
    x_aligned_full[:, trial_index] = x_local
    
    sin_aligned_full[:, trial_index] = x_fitted

    # =====================
    
    t = t[:16384]                         #slicing up to 2^k (k = 14);

    # =====================
    
    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'g', alpha = 0.3, linewidth = 1.0)
    #plt.plot(t, x_fitted, 'b', alpha = 0.3, linewidth = 1.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

# =========================================================
    
#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, x_aligned_full[:, 0:6], 'b', alpha = 0.3, linewidth = 0.1)
#plt.plot(t, sin_aligned_full[:, 0:6], 'b', alpha = 0.3, linewidth = 0.1)
#plt.plot(t, x_aligned_full[:, 6:11], 'y', alpha = 0.8, linewidth = 0.1)
#plt.plot(t, sin_aligned_full[:, 6:11], 'y', alpha = 0.3, linewidth = 0.1)
#plt.show()

# =========================================================
#      TO MAINTAIN COMPARABILITY BETWEEN FREQUENCIES      =
#        GIVEN THAT THEY WILL BE ENDING AT DIFFERENT      =
#        PHASES OF THEIR CYCLE IT IS NECESSARY TO         =
#                   APPLY A HANN WINDOW:                  =
# =========================================================
    
hann_unity = np.zeros([16384, 11])

row = 0

for evaluation_number in range (16384) :

    hann_unity[row, :] = (1 - np.cos(2 * np.pi * (row/16384)))/2

    row = row + 1

# =====================

#plt.figure(figsize = (12, 6), dpi = 1200)
#plt.plot(t, hann_unity, 'b', alpha = 0.5, linewidth = 0.5)
#plt.show()

# =====================

A = x_aligned_full

x_aligned_full = x_aligned_full * hann_unity

# =====================

#plt.figure(figsize = (12, 6), dpi = 1200)
#plt.plot(t, hann_unity[:, 0]*np.max(A[:, 0]), 'b', alpha = 0.3, linewidth = 0.5)
#plt.plot(t, hann_unity[:, 0]*np.min(A[:, 0]), 'b', alpha = 0.3, linewidth = 0.5)
#plt.plot(t, x_aligned_full[:, 0], 'y', alpha = 0.5, linewidth = 0.5)
#plt.show()

# =========================================================
#    TRANSFORMING THE SIGNAL INTO THE FREQUENCY DOMAIN:   =
# =========================================================

X_full_butterfly = np.zeros([16384, 11], dtype = np.complex128)

x_solver = np.zeros([16384, 1])

test_index = 0

for evaluation_number in range (11) :
    
    x_solver[:, 0] = x_aligned_full[:, test_index]
    
    X_full_butterfly[:, test_index] = 2 * (FFT_function(x_solver[:, 0]))
    
    test_index = test_index + 1
    
# =====================
    
samples = 16384
    
frequency_bins = np.arange(samples)

# =====================

#plt.figure(figsize = (20, 8), dpi = 1200)
#plt.plot(frequency_bins, abs(X_full_butterfly[:, 0]), 'b', alpha = 0.3, linewidth = 0.5)
#plt.show()

# ==========================================
# NORMALISING AND SLICING THE FREQUENCIES: =
# ==========================================

midpoint = 8192

duration = 3.2766

# =====================

freq_butterfly =  frequency_bins / duration

freq = freq_butterfly[:midpoint]

# ==========================================
#  SLICING AND NORMALISING THE AMPLITUDES: =
# ==========================================

X_full = np.zeros([8192, 11], dtype = np.complex128)

test_index = 0

for evaluation_number in range(11) :
    
    X_solver = X_full_butterfly[:, test_index]
    
    X_full[:, test_index] = X_solver[:midpoint]/midpoint
    
    test_index = test_index + 1

# =========================================================
#   AMPLITUDES AT EACH BIN [TAKING OUT OF COMPLEX FORM]:  =
# =========================================================

X_full = np.abs(X_full)

# =========================================================
# ================= STATISTICAL ANALYSIS: =================
# =========================================================

mean_vector = np.zeros([midpoint, 1])

row = 0

for evaluation_number in range (midpoint) :
    
    mean_vector[row, 0] = np.sum(X_full[row, [0, 1, 2, 3, 4, 5]])/6
    
    row = row + 1

# =====================

DC_filter = np.ones([8192, 1])

DC_filter[[0, 1, 2, 3], 0] = 0            # removing the DC bias manually

X_full = X_full * DC_filter

# =====================

plt.figure(figsize = (20, 6), dpi = 1200)
plt.title('Excitation Frequency: %.0f (Hz)                     Statistical Moment 1 [Mean] of the Six Healthy Sets and a Single Damaged Set - Per Bin in the Frequency Domain                        Location: %s' % (excitation_frequency, location_tag), fontsize = 11)      #don't mind me   
plt.plot(freq, X_full[:, [0, 1, 2, 3, 4, 5]], 'g', alpha = 0.2, linewidth = 0.4)
plt.plot(freq, mean_vector, 'g', alpha = 0.6, linewidth = 0.4)
plt.plot(freq, X_full[:, [damage_index]], 'r', alpha = 0.4, linewidth = 0.4)
plt.axhline(y = 0, color = 'black', linestyle = '-', alpha = 0.4, linewidth = 0.1)
plt.ylim(-0.05*np.max(X_full[:, [0, 1, 2, 3, 4, 5, damage_index]]), 1.1*np.max(X_full[:, [0, 1, 2, 3, 4, 5, damage_index]]))
plt.plot(0, 0, color='g', alpha = 0.5, linewidth = 1.0, label = 'Healthy')
plt.plot(0, 0, color='r', alpha = 0.5, linewidth = 1.0, label = '%s' % (damage_level_tag))
plt.legend(fontsize = 11, loc = 'upper right')
plt.xlabel('Frequency (Hz)', fontsize = 11)
plt.ylabel('Amplitude (m/s²)', labelpad = 15, fontsize = 11)
plt.xlim(-50, 2550)
for x in harmonic_lines :
    
    plt.plot([x, x], [-plt.ylim()[1], plt.ylim()[1]], color = 'black', linestyle = '-', alpha = 0.4, linewidth = 0.1)
    
plt.show()

# =====================

plt.figure(figsize = (20, 6), dpi = 1200)
plt.title('Excitation Frequency: %.0f (Hz)                     Statistical Moment 1 [Mean] of the Six Healthy Sets and a Single Damaged Set - Per Bin in the Frequency Domain                        Location: %s' % (excitation_frequency, location_tag), fontsize = 11)      #don't mind me 
plt.plot(freq, X_full[:, [0, 1, 2, 3, 4, 5]], 'g', alpha = 0.15, linewidth = 1.5)
plt.plot(freq, mean_vector, 'g', alpha = 0.6, linewidth = 1.5)
plt.plot(freq, X_full[:, [damage_index]], 'r', alpha = 0.4, linewidth = 1.5)
plt.axhline(y = 0, color = 'black', linestyle = '-', alpha = 0.4, linewidth = 0.1)
plt.xlim(lower_bound_detailed, upper_bound_detailed)
plt.ylim(-0.05*np.max(X_full[bin_index_lower:bin_index_upper, [0, 1, 2, 3, 4, 5, damage_index]]), 1.1*np.max(X_full[bin_index_lower:bin_index_upper, [0, 1, 2, 3, 4, 5, damage_index]]))        #don't mind me  
plt.xlabel('Frequency (Hz)', fontsize = 11)
plt.ylabel('Amplitude (m/s²)', labelpad = 15, fontsize = 11)
plt.plot(0, 0, color ='g', alpha = 0.5, linewidth = 1.0, label = 'Healthy')
plt.plot(0, 0, color ='r', alpha = 0.5, linewidth = 1.0, label = '%s' % (damage_level_tag))
plt.legend(fontsize = 11, loc = 'upper right')
plt.xlabel('Frequency (Hz)', fontsize = 11)
plt.ylabel('Amplitude (m/s²)', labelpad = 15, fontsize = 11)

for x in harmonic_lines :
    
    plt.plot([x, x], [-plt.ylim()[1], plt.ylim()[1]], color = 'black', linestyle = '-', alpha = 0.4, linewidth = 0.1)
    
plt.show()

# =========================================================




