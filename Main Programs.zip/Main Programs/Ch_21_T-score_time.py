

# =====================
import numpy as np
# =====================
from scipy.optimize import curve_fit
# =====================
import matplotlib.pyplot as plt
# =====================
import matplotlib.image as mpimg
# =====================
from trial_solver import trial_function
# =====================


# ==========================================
#   MODULATE THE TWO BELOW - EVERYTHING    =
#            ELSE IS AUTOMATED:            =
# ==========================================

excitation_frequency = 10    # (Hz)

# =====================

accelerometer_channel = 2   # 2 = Nacelle
                            # 3 = Landing Platform

# =====================

damage_index = 6             # L1 = 6; L2 = 7...

# ==========================================

img = mpimg.imread('test matrices.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('moments_1_and_2_time.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('T_score_time.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

trial_1, trial_2, trial_3, trial_4, trial_5, trial_6, L1, L2, L3, L4, L5 = trial_function(excitation_frequency)      #don't mind me    

# =====================

x_full = np.zeros([25000, 11])

# =====================

column_index = accelerometer_channel

# =====================

x_full[:, 0]  = trial_1[:, column_index]
x_full[:, 1]  = trial_2[:, column_index]
x_full[:, 2]  = trial_3[:, column_index]
x_full[:, 3]  = trial_4[:, column_index]
x_full[:, 4]  = trial_5[:, column_index]
x_full[:, 5]  = trial_6[:, column_index]
x_full[:, 6]  =      L1[:, column_index]
x_full[:, 7]  =      L2[:, column_index]
x_full[:, 8]  =      L3[:, column_index]
x_full[:, 9]  =      L4[:, column_index]
x_full[:, 10] =      L5[:, column_index]

# =====================

x_full_sync = np.zeros([25000, 11])

# =====================

x_full_sync[:, 0]  = trial_1[:, 3]
x_full_sync[:, 1]  = trial_2[:, 3]
x_full_sync[:, 2]  = trial_3[:, 3]
x_full_sync[:, 3]  = trial_4[:, 3]
x_full_sync[:, 4]  = trial_5[:, 3]
x_full_sync[:, 5]  = trial_6[:, 3]
x_full_sync[:, 6]  =      L1[:, 3]
x_full_sync[:, 7]  =      L2[:, 3]
x_full_sync[:, 8]  =      L3[:, 3]
x_full_sync[:, 9]  =      L4[:, 3]
x_full_sync[:, 10] =      L5[:, 3]

# =====================

if column_index == 2 :
    
    location_tag = "Nacelle"
    
if column_index == 3 :
    
    location_tag = "Landing Platform"

# =========================================================
# ================= CHECKING DIVISIBILITY: ================
# =========================================================

if 5000 % excitation_frequency != 0 :
    
    remainder = round(((5000 % excitation_frequency) / excitation_frequency)**-1) - 1

    print("The sample rate and excitation")
    print("frequency aren't playing nice ")
    print("together - we're going to have")
    print("to skip:                      ")
    print("                              ")
    print("          %.0f cycles" % remainder)
    print("                              ")
    print(" ...between each visualised"   )
    print("  and evaluated cycle for"     )
    print("      proper alignment."       )
    print("\n-----------------------------\n")
    
else :
        
    remainder = 0

# =========================================================
# =================== ALIGNING THE SETS ===================
# =========================================================

full = 5000 // (1 * excitation_frequency)

full_float = 5000 / excitation_frequency

# =====================

#ten_cycles = 10 * full

necessary_cycles = round((remainder + 1) * 10 * full_float)

# =====================

half = 5000 // (2 * excitation_frequency)

half_float = 5000 / (2 * excitation_frequency)

# =====================

three_quarter = (3 * 5000) // (4 * excitation_frequency)
  
three_quarter_float = (3 * 5000) / (4 * excitation_frequency)

# =====================

x_aligned_full = np.zeros([necessary_cycles, 11])

sin_aligned_full = np.zeros([necessary_cycles, 11])

# =========================================================
# ============ TEMPORAL ALIGNMENT FOR LOOP: ===============
# =========================================================

for trial_index in range (11) :

    # =====================
    
    x_local_sync = x_full_sync[:, trial_index]
    
    x_local = x_full[:, trial_index]

    # =====================
    
    t = np.arange(0, 5, 0.0002)  

    # ==========================================
    # ============ fitting function: ===========
    # ==========================================
    
    t_fitted = t
    
    y = x_local_sync
    
    # =====================
    
    initial_guess = [1.3, excitation_frequency, 0.0, 0.0]
    
    # =====================
    
    def sine_func(t_fitted, A, f, phi, offset) :
        
        return A * np.sin(2 * np.pi * f * t_fitted + phi) + offset

    # =====================
    
    params, _ = curve_fit(sine_func, t_fitted, y, p0=initial_guess)
    
    A_fit, f_fit, phi_fit, offset_fit = params
    
    x_fitted = sine_func(t_fitted, A_fit, f_fit, phi_fit, offset_fit)
    
    # =====================
    
    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.plot(t_fitted, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

    # ==========================================
    # ============= ascending case =============
    # ==========================================
    
    if x_fitted[1] > x_fitted[0] :         
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # ==========================================
    # ============ descending case =============
    # ==========================================
    
    elif x_fitted[1] < x_fitted[0] :
        
        x_local = x_local[half:]
        
        x_fitted = x_fitted[half:]
        
    # =====================
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # =====================
    
    C = counter_1 + three_quarter         #preferred this location aesthetically
    
    # =====================
    
    x_local = x_local[C:]                 #slicing from preferred location
    
    x_fitted = x_fitted[C:]               #slicing from preferred location
    
    # =====================
    
    x_local = x_local[:necessary_cycles]                #slicing up to ten cycles [or that which facilitates a coherent mapping of ten]
    
    x_fitted = x_fitted[:necessary_cycles]              #slicing up to ten cycles [or that which facilitates a coherent mapping of ten]
    
    # =====================

    x_aligned_full[:, trial_index] = x_local
    
    sin_aligned_full[:, trial_index] = x_fitted
    
    t = t[:necessary_cycles]                            

    # =====================

    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

# =========================================================
# =================== SLICING THE SETS: ===================
# =========================================================

t = t[:full]

# =====================


trial_1_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_1_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 0]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1


# =====================


trial_2_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_2_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 1]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_3_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_3_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 2]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_4_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_4_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 3]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_5_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_5_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 4]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_6_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_6_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 5]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


L1_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L1_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 6]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L2_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L2_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 7]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L3_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L3_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 8]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L4_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L4_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 9]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L5_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L5_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 10]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, trial_1_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_2_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_3_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_4_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_5_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, trial_6_sliced, 'b', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L1_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L2_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L3_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L4_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.plot(t, L5_sliced, 'y', alpha = 0.2, linewidth = 0.2)
#plt.show()

# =========================================================
# ================= STATISTICAL ANALYSIS: =================
# =========================================================

number_of_time_bins = full

# =====================

statistical_baseline = np.column_stack(( trial_1_sliced, \
                                         trial_2_sliced, \
                                         trial_3_sliced, \
                                         trial_4_sliced, \
                                         trial_5_sliced, \
                                         trial_6_sliced    ))

# =====================

mean_vector = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector[row, 0] = np.sum(statistical_baseline[row, :])/60
    
    row = row + 1

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, statistical_baseline, 'b', alpha = 0.2, linewidth = 0.05)
#plt.plot(t, mean_vector, 'b', alpha = 0.8, linewidth = 0.2)
#plt.show()

# =====================

sigma_vector = np.zeros([full, 1])

# =====================

time_bin_index = 0

for evaluation_number_2 in range (full) :

    sub_calc_1 = np.zeros([60, 1])
    
    row = 0
    
    mean = mean_vector[time_bin_index]
    
    for evaluation_number_1 in range (60) :
        
        sub_calc_1[row, 0] = (statistical_baseline[time_bin_index, row] - mean[0])**2
        
        row = row + 1
    
    sigma_vector[time_bin_index, 0] = np.sqrt(np.sum(sub_calc_1) / 60)
    
    time_bin_index = time_bin_index + 1

# =====================

contour_upper = mean_vector + sigma_vector

contour_lower = mean_vector - sigma_vector

# =====================

contour_lower = contour_lower.flatten()

contour_upper = contour_upper.flatten()

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, statistical_baseline, 'b', alpha = 0.2, linewidth = 0.05)
#plt.fill_between(t, contour_lower, contour_upper, color = 'gray', alpha = 0.3, edgecolor = 'none')
#plt.plot(t, mean_vector, color = 'b', alpha = 0.8, linewidth = 0.2)
#plt.plot(t, contour_upper, color = 'b', alpha = 0.8, linewidth = 0.2, linestyle = '--')
#plt.plot(t, contour_lower, color = 'b', alpha = 0.8, linewidth = 0.2, linestyle = '--')
#plt.show()

# =====================

mean_vector_trial_1 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_trial_1[row, 0] = np.sum(trial_1_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_trial_2 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_trial_2[row, 0] = np.sum(trial_2_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_trial_3 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_trial_3[row, 0] = np.sum(trial_3_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_trial_4 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_trial_4[row, 0] = np.sum(trial_4_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_trial_5 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_trial_5[row, 0] = np.sum(trial_5_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_trial_6 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_trial_6[row, 0] = np.sum(trial_6_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_L1 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_L1[row, 0] = np.sum(L1_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_L2 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_L2[row, 0] = np.sum(L2_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_L3 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_L3[row, 0] = np.sum(L3_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_L4 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_L4[row, 0] = np.sum(L4_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

mean_vector_L5 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    mean_vector_L5[row, 0] = np.sum(L5_sliced[row, :]) / 10
    
    row = row + 1
    
# =====================

#plt.figure(figsize = (25, 6), dpi = 600)
#plt.fill_between(t, contour_lower, contour_upper, color = 'gray', alpha = 0.2, edgecolor = 'none')
#plt.plot(t, statistical_baseline, 'g', alpha = 0.2, linewidth = 0.05)
#plt.plot(t, mean_vector_trial_1, color = 'g', alpha = 0.8, linewidth = 0.15)
#plt.plot(t, mean_vector_trial_2, color = 'g', alpha = 0.8, linewidth = 0.15)
#plt.plot(t, mean_vector_trial_3, color = 'g', alpha = 0.8, linewidth = 0.15)
#plt.plot(t, mean_vector_trial_4, color = 'g', alpha = 0.8, linewidth = 0.15)
#plt.plot(t, mean_vector_trial_5, color = 'g', alpha = 0.8, linewidth = 0.15)
#plt.plot(t, mean_vector_trial_6, color = 'g', alpha = 0.8, linewidth = 0.15)
#plt.plot(t, mean_vector, color = 'k', alpha = 0.6, linewidth = 0.2)
#plt.plot(t, contour_upper, color = 'k', alpha = 0.6, linewidth = 0.2, linestyle = '--')
#plt.plot(t, contour_lower, color = 'k', alpha = 0.6, linewidth = 0.2, linestyle = '--')
#plt.plot(t, L3_sliced, 'r', alpha = 0.3, linewidth = 0.05)
#plt.plot(t, mean_vector_L3, color = 'r', alpha = 0.8, linewidth = 0.15)
#plt.plot(0, 0, color = 'k', alpha = 0.6, linewidth = 1.0, label='Mean [per bin]')
#plt.plot(0, 0, color = 'k', alpha = 0.6, linewidth = 1.0, linestyle = '--', label='±1σ bounds [per bin]')
#plt.legend()
#plt.legend(loc='upper right')
#plt.show()

# =====================

residual_deviation_trial_1 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_trial_1[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_trial_1[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_trial_1[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_trial_1 = np.cumsum(sub_calc / full)

T_score_trial_1 = np.sum(sub_calc[:, 0]) / full

# =====================

#plt.figure(figsize = (25, 6), dpi = 300)
#plt.plot(t, uncollapsed_trial_1, 'b', alpha = 0.6, linewidth = 2.0)
#plt.show()

# =====================

residual_deviation_trial_2 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_trial_2[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_trial_2[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_trial_2[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_trial_2 = np.cumsum(sub_calc / full)

T_score_trial_2 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_trial_3 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_trial_3[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_trial_3[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_trial_3[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_trial_3 = np.cumsum(sub_calc / full)

T_score_trial_3 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_trial_4 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_trial_4[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_trial_4[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_trial_4[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_trial_4 = np.cumsum(sub_calc / full)

T_score_trial_4 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_trial_5 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_trial_5[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_trial_5[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_trial_5[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_trial_5 = np.cumsum(sub_calc / full)

T_score_trial_5 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_trial_6 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_trial_6[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_trial_6[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_trial_6[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_trial_6 = np.cumsum(sub_calc / full)

T_score_trial_6 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_L1 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_L1[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_L1[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_L1[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_L1 = np.cumsum(sub_calc / full)

T_score_L1 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_L2 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_L2[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_L2[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_L2[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_L2 = np.cumsum(sub_calc / full)

T_score_L2 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_L3 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_L3[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_L3[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_L3[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_L3 = np.cumsum(sub_calc / full)

T_score_L3 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_L4 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_L4[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_L4[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_L4[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_L4 = np.cumsum(sub_calc / full)

T_score_L4 = np.sum(sub_calc[:, 0]) / full

# =====================

residual_deviation_L5 = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    residual_deviation_L5[row, 0] = np.abs(mean_vector[row, 0] - mean_vector_L5[row, 0])
    
    row = row + 1

# =====================

sub_calc = np.zeros([full, 1])

row = 0

for evaluation_number in range (full) :
    
    sub_calc[row, 0] = (residual_deviation_L5[row, 0] / sigma_vector[row, 0])**2
    
    row = row + 1

uncollapsed_L5 = np.cumsum(sub_calc / full)

T_score_L5 = np.sum(sub_calc[:, 0]) / full

# =====================

if damage_index == 6 :
    
    damage_level_tag = "L1"

if damage_index == 7 :
    
    damage_level_tag = "L2"

if damage_index == 8 :
    
    damage_level_tag = "L3"
    
if damage_index == 9 :
    
    damage_level_tag = "L4"
    
if damage_index == 10 :
    
    damage_level_tag = "L5"

# =====================

if damage_index == 6 :
    
    A = uncollapsed_L1
    
if damage_index == 7 :
    
    A = uncollapsed_L2
    
if damage_index == 8 :
    
    A = uncollapsed_L3
    
if damage_index == 9 :
    
    A = uncollapsed_L4
    
if damage_index == 10 :
    
    A = uncollapsed_L5

# =====================

if damage_index == 6 :
    
    B = L1_sliced
    
if damage_index == 7 :
    
    B = L2_sliced
    
if damage_index == 8 :
    
    B = L3_sliced
    
if damage_index == 9 :
    
    B = L4_sliced
    
if damage_index == 10 :
    
    B = L5_sliced

# =====================

if damage_index == 6 :
    
    C = mean_vector_L1

if damage_index == 7 :
    
    C = mean_vector_L2
    
if damage_index == 8 :
    
    C = mean_vector_L3
    
if damage_index == 9 :
    
    C = mean_vector_L4
    
if damage_index == 10 :
    
    C = mean_vector_L5

# ===============================================================

fig, axs = plt.subplots(2, 1, figsize=(25, 12), dpi = 600)

axs[0].set_title('Excitation Frequency: %.0f (Hz)                                            Cumulative T-score                                            Location: %s' % (excitation_frequency, location_tag), fontsize = 15)     #don't mind me... 
axs[0].plot(0, 0, color='b', alpha=0.9, linewidth=1.0, label='Healthy')
axs[0].plot(0, 0, color='y', alpha=1.0, linewidth=1.0, label='%s' % damage_level_tag)  
axs[0].legend(fontsize = 15, loc = 'upper left')
axs[0].set_xlabel('Time (s)', fontsize=15)
axs[0].set_ylabel('Cumulative T-score', labelpad=15, fontsize=15)
axs[0].plot(t, uncollapsed_trial_1, 'b', alpha = 0.6, linewidth = 1.0)
axs[0].plot(t, uncollapsed_trial_2, 'b', alpha = 0.6, linewidth = 1.0)
axs[0].plot(t, uncollapsed_trial_3, 'b', alpha = 0.6, linewidth = 1.0)
axs[0].plot(t, uncollapsed_trial_4, 'b', alpha = 0.6, linewidth = 1.0)
axs[0].plot(t, uncollapsed_trial_5, 'b', alpha = 0.6, linewidth = 1.0)
axs[0].plot(t, uncollapsed_trial_6, 'b', alpha = 0.6, linewidth = 1.0)
axs[0].plot(t, A,                   'y', alpha = 1.0, linewidth = 1.0)
axs[0].tick_params(axis = 'both', labelsize = 15)

# =====================

axs[1].set_title('Excitation Frequency: %.0f (Hz)                                            Time Domain Signal for Reference                                           Location: %s' % (excitation_frequency, location_tag), fontsize=15)
axs[1].fill_between(t, contour_lower, contour_upper, color = 'gray', alpha = 0.2, edgecolor = 'none')
axs[1].plot(t, statistical_baseline, 'g', alpha = 0.2, linewidth = 0.05)
axs[1].plot(0, 0, color='g', alpha=0.9, linewidth=1.0, label='Healthy')
axs[1].plot(0, 0, color='r', alpha=0.8, linewidth=1.0, label='%s' % damage_level_tag)
axs[1].legend(fontsize = 15, loc = 'upper right')
axs[1].set_xlabel('Time (s)', fontsize=15)
axs[1].set_ylabel('Amplitude (m/s²)', labelpad=15, fontsize=15)
axs[1].plot(t, mean_vector_trial_1, color = 'g', alpha = 0.8, linewidth = 0.15)
axs[1].plot(t, mean_vector_trial_2, color = 'g', alpha = 0.8, linewidth = 0.15)
axs[1].plot(t, mean_vector_trial_3, color = 'g', alpha = 0.8, linewidth = 0.15)
axs[1].plot(t, mean_vector_trial_4, color = 'g', alpha = 0.8, linewidth = 0.15)
axs[1].plot(t, mean_vector_trial_5, color = 'g', alpha = 0.8, linewidth = 0.15)
axs[1].plot(t, mean_vector_trial_6, color = 'g', alpha = 0.8, linewidth = 0.15)
axs[1].plot(t, mean_vector, color = 'k', alpha = 0.6, linewidth = 0.2)
axs[1].plot(t, contour_upper, color = 'k', alpha = 0.6, linewidth = 0.2, linestyle = '--')
axs[1].plot(t, contour_lower, color = 'k', alpha = 0.6, linewidth = 0.2, linestyle = '--')
axs[1].plot(t, B, 'r', alpha = 0.3, linewidth = 0.05)
axs[1].plot(t, C, color = 'r', alpha = 0.8, linewidth = 0.15)
axs[1].plot(0, 0, color = 'k', alpha = 0.6, linewidth = 1.0)
axs[1].plot(0, 0, color = 'k', alpha = 0.6, linewidth = 1.0, linestyle = '--')
axs[1].legend(fontsize = 15, loc = 'upper right')
axs[1].tick_params(axis = 'both', labelsize = 15)

# =====================

plt.tight_layout()

plt.show()

# ===============================================================

x_values_healthy = np.arange(1, 7, 1)

x_values_damaged = np.arange(1.5, 6.5, 1)

# =====================

y_values_healthy = np.zeros([6, 1])

y_values_healthy[0, 0] = T_score_trial_1
y_values_healthy[1, 0] = T_score_trial_2
y_values_healthy[2, 0] = T_score_trial_3
y_values_healthy[3, 0] = T_score_trial_4
y_values_healthy[4, 0] = T_score_trial_5
y_values_healthy[5, 0] = T_score_trial_6

y_values_damaged = np.zeros([5, 1])

y_values_damaged[0, 0] = T_score_L1
y_values_damaged[1, 0] = T_score_L2
y_values_damaged[2, 0] = T_score_L3
y_values_damaged[3, 0] = T_score_L4
y_values_damaged[4, 0] = T_score_L5

# =====================

combined_array = np.zeros([11, 1])

combined_array[0:6] = y_values_healthy

combined_array[6:11] = y_values_damaged

# =====================

y_upper = max(combined_array)

y_lower = min(combined_array)

delta = max(combined_array) - min(combined_array)

# =====================

plt.figure(figsize = (8, 6), dpi = 1200)

plt.title('Excitation Frequency: %.0f (Hz)          Location: %s        Number of Time Bins: %.0f' % (excitation_frequency, location_tag, full), fontsize=9)

plt.scatter(x_values_healthy, y_values_healthy, c = 'g', label = 'Healthy')

plt.scatter(x_values_damaged, y_values_damaged, c = 'r', label = 'Damaged')

plt.ylabel("T-score Amplitude", labelpad=10, fontsize=11)

plt.text(x_values_healthy[0], y_values_healthy[0]-(0.038*delta), "Trial 1:\n%.3f" % combined_array[0, 0], fontsize=9, ha='center', va='top')                 #don't mind me         
plt.text(x_values_healthy[1], y_values_healthy[1]-(0.038*delta), "Trial 2:\n%.3f" % combined_array[1, 0], fontsize=9, ha='center', va='top') 
plt.text(x_values_healthy[2], y_values_healthy[2]-(0.038*delta), "Trial 3:\n%.3f" % combined_array[2, 0], fontsize=9, ha='center', va='top') 
plt.text(x_values_healthy[3], y_values_healthy[3]-(0.038*delta), "Trial 4:\n%.3f" % combined_array[3, 0], fontsize=9, ha='center', va='top') 
plt.text(x_values_healthy[4], y_values_healthy[4]-(0.038*delta), "Trial 5:\n%.3f" % combined_array[4, 0], fontsize=9, ha='center', va='top') 
plt.text(x_values_healthy[5], y_values_healthy[5]-(0.038*delta), "Trial 6:\n%.3f" % combined_array[5, 0], fontsize=9, ha='center', va='top') 

plt.text(x_values_damaged[0], y_values_damaged[0]-(0.038*delta), "L1:\n%.3f" % combined_array[6, 0], fontsize=9, ha='center', va='top')
plt.text(x_values_damaged[1], y_values_damaged[1]-(0.038*delta), "L2:\n%.3f" % combined_array[7, 0], fontsize=9, ha='center', va='top')
plt.text(x_values_damaged[2], y_values_damaged[2]-(0.038*delta), "L3:\n%.3f" % combined_array[8, 0], fontsize=9, ha='center', va='top')
plt.text(x_values_damaged[3], y_values_damaged[3]-(0.038*delta), "L4:\n%.3f" % combined_array[9, 0], fontsize=9, ha='center', va='top')
plt.text(x_values_damaged[4], y_values_damaged[4]-(0.038*delta), "L5:\n%.3f" % combined_array[10, 0], fontsize=9, ha='center', va='top')

plt.ylim(y_lower-(0.2*delta), y_upper+(0.25*delta))

plt.xlim(0.5, 6.5)

plt.xticks([])

plt.legend()

plt.legend(loc='upper right')

plt.axhline(y = y_values_healthy[0, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_healthy[1, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_healthy[2, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_healthy[3, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_healthy[4, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_healthy[5, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)

plt.axhline(y = y_values_damaged[0, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_damaged[1, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_damaged[2, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_damaged[3, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
plt.axhline(y = y_values_damaged[4, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)

plt.show()






