

# =====================
import numpy as np
# =====================
from scipy.optimize import curve_fit
# =====================
from FFT_solver import FFT_function
# =====================
import matplotlib.pyplot as plt
# =====================
import matplotlib.image as mpimg
# =====================
from trial_solver import trial_function
# =====================


# ==========================================
#   MODULATE THE FOUR BELOW - EVERYTHING   =
#            ELSE IS AUTOMATED:            =
# ==========================================

excitation_frequency = 10       # (Hz)

# =====================

accelerometer_channel = 2      # 2 = Nacelle
                               # 3 = Landing Platform

# =====================

damage_index = 6               # L1 = 6; L2 = 7...

# =====================

threshold_percentage = 0.01    #0.01 = 1%

# ==========================================

img = mpimg.imread('test matrices.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('T_score_amplitude.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

img = mpimg.imread('T_score_phase.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

trial_1, trial_2, trial_3, trial_4, trial_5, trial_6, L1, L2, L3, L4, L5 = trial_function(excitation_frequency)      #don't mind me    

# =====================

x_full = np.zeros([25000, 11])

# =====================

column_index = accelerometer_channel

# =====================

x_full[:, 0]  = trial_1[:, column_index]
x_full[:, 1]  = trial_2[:, column_index]
x_full[:, 2]  = trial_3[:, column_index]
x_full[:, 3]  = trial_4[:, column_index]
x_full[:, 4]  = trial_5[:, column_index]
x_full[:, 5]  = trial_6[:, column_index]
x_full[:, 6]  =      L1[:, column_index]
x_full[:, 7]  =      L2[:, column_index]
x_full[:, 8]  =      L3[:, column_index]
x_full[:, 9]  =      L4[:, column_index]
x_full[:, 10] =      L5[:, column_index]

# =====================

x_full_sync = np.zeros([25000, 11])

# =====================

x_full_sync[:, 0]  = trial_1[:, 3]
x_full_sync[:, 1]  = trial_2[:, 3]
x_full_sync[:, 2]  = trial_3[:, 3]
x_full_sync[:, 3]  = trial_4[:, 3]
x_full_sync[:, 4]  = trial_5[:, 3]
x_full_sync[:, 5]  = trial_6[:, 3]
x_full_sync[:, 6]  =      L1[:, 3]
x_full_sync[:, 7]  =      L2[:, 3]
x_full_sync[:, 8]  =      L3[:, 3]
x_full_sync[:, 9]  =      L4[:, 3]
x_full_sync[:, 10] =      L5[:, 3]

# =====================

if column_index == 2 :
    
    location_tag = "Nacelle"
    
if column_index == 3 :
    
    location_tag = "Landing Platform"

# =====================

if damage_index == 6 :
    
    damage_level_tag = "L1"

if damage_index == 7 :
    
    damage_level_tag = "L2"

if damage_index == 8 :
    
    damage_level_tag = "L3"
    
if damage_index == 9 :
    
    damage_level_tag = "L4"
    
if damage_index == 10 :
    
    damage_level_tag = "L5"

# =========================================================
# =================== ALIGNING THE SETS ===================
# =========================================================

x_aligned_full = np.zeros([16384, 11])

sin_aligned_full = np.zeros([16384, 11])

# =====================

full = 5000 // (1 * excitation_frequency)

# =====================

half = 5000 // (2 * excitation_frequency)

# =====================

three_quarter = (3 * 5000) // (4 * excitation_frequency)

# =========================================================
# ============ TEMPORAL ALIGNMENT FOR LOOP: ===============
# =========================================================

for trial_index in range (11) :

    # =====================
    
    x_local_sync = x_full_sync[:, trial_index]
    
    x_local = x_full[:, trial_index]
    
    # =====================
    
    t = np.arange(0, 5, 0.0002)  

    # ==========================================
    # ============ fitting function: ===========
    # ==========================================
    
    t_fitted = t
    
    y = x_local_sync
    
    # =====================
    
    initial_guess = [1.3, excitation_frequency, 0.0, 0.0]
    
    # =====================
    
    def sine_func(t_fitted, A, f, phi, offset) :
        
        return A * np.sin(2 * np.pi * f * t_fitted + phi) + offset
    
    params, _ = curve_fit(sine_func, t_fitted, y, p0=initial_guess)
    
    A_fit, f_fit, phi_fit, offset_fit = params
    
    x_fitted = sine_func(t_fitted, A_fit, f_fit, phi_fit, offset_fit)
    
    # =====================
    
    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.plot(t_fitted, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

    # ==========================================
    # ============= ascending case =============
    # ==========================================
    
    if x_fitted[1] > x_fitted[0] :         
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # ==========================================
    # ============ descending case =============
    # ==========================================
    
    elif x_fitted[1] < x_fitted[0] :
        
        x_local = x_local[half:]
        
        x_fitted = x_fitted[half:]
        
    # =====================
        
        counter_1 = 0
        
        for evaluation_number in range(24000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # =====================
    
    C = counter_1 + three_quarter         #preferred this location aesthetically
    
    # =====================
    
    x_local = x_local[C:]                 #slicing from preferred location
    
    x_fitted = x_fitted[C:]               #slicing from preferred location
    
    # =====================
    
    x_local = x_local[:16384]             #slicing up to 2^k (k = 14)
    
    x_fitted = x_fitted[:16384]           #slicing up to 2^k (k = 14)
    
    # =====================
    
    x_aligned_full[:, trial_index] = x_local
    
    sin_aligned_full[:, trial_index] = x_fitted
    
    t = t[:16384]                         #slicing up to 2^k (k = 14);

    # =====================

    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.plot(t, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

# =========================================================
    
#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(t, x_aligned_full[:, 0:6], 'y', alpha = 0.4, linewidth = 0.1)
#plt.plot(t, x_aligned_full[:, 6:11], 'b', alpha = 0.2, linewidth = 0.1)
#plt.plot(t, sin_aligned_full[:, 0:6], 'y', alpha = 0.4, linewidth = 0.1)
#plt.plot(t, sin_aligned_full[:, 6:11], 'b', alpha = 0.2, linewidth = 0.1)
#plt.show()

# =========================================================
#          TRANSFORMING INTO THE FREQUENCY DOMAIN:        =
# =========================================================

hann_unity = np.zeros([16384, 11])

row = 0

for evaluation_number in range (16384) :

    hann_unity[row, :] = (1 - np.cos(2 * np.pi * (row/16384)))/2

    row = row + 1
    
# =====================

x_aligned_full = x_aligned_full * hann_unity

# =====================

X_full_butterfly = np.zeros([16384, 11], dtype=np.complex128)

x_solver = np.zeros([16384, 1])

test_index = 0

for evaluation_number in range (11) :
    
    x_solver[:, 0] = x_aligned_full[:, test_index]
    
    X_full_butterfly[:, test_index] = 2 * (FFT_function(x_solver[:, 0]))
    
    test_index = test_index + 1

# =========================================================
#              SLICING THE ARRAY IN HALF AND              =
#               NORMALISING THE AMPLITUDES:               =
# =========================================================

duration = 3.2766

samples = 16384

midpoint = samples // 2

# =====================

integers = np.arange(samples)

freq_butterfly =  integers / duration

freq = freq_butterfly[:midpoint]

# =====================

X_full = np.zeros([8192, 11], dtype=np.complex128)

test_index = 0

for evaluation_number in range(11) :
    
    X_solver = X_full_butterfly[:, test_index]
    
    X_full[:, test_index] = X_solver[:midpoint]/midpoint
    
    test_index = test_index + 1

# =========================================================
#                       AMPLITUDE:                        =
# =========================================================

X_full_abs = np.abs(X_full)

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(freq, X_full_abs, 'b', alpha = 0.3, linewidth = 0.1)
#plt.xlim(0, 50)
#plt.show()

# =========================================================
#                          PHASE:                         =
# =========================================================

X_full_phase = np.zeros([8192, 11])

X_full_phase[:,  0] = np.arctan2(np.imag(X_full[:,  0]), np.real(X_full[:,  0]))
X_full_phase[:,  1] = np.arctan2(np.imag(X_full[:,  1]), np.real(X_full[:,  1]))
X_full_phase[:,  2] = np.arctan2(np.imag(X_full[:,  2]), np.real(X_full[:,  2]))
X_full_phase[:,  3] = np.arctan2(np.imag(X_full[:,  3]), np.real(X_full[:,  3]))
X_full_phase[:,  4] = np.arctan2(np.imag(X_full[:,  4]), np.real(X_full[:,  4]))
X_full_phase[:,  5] = np.arctan2(np.imag(X_full[:,  5]), np.real(X_full[:,  5]))
X_full_phase[:,  6] = np.arctan2(np.imag(X_full[:,  6]), np.real(X_full[:,  6]))
X_full_phase[:,  7] = np.arctan2(np.imag(X_full[:,  7]), np.real(X_full[:,  7]))
X_full_phase[:,  8] = np.arctan2(np.imag(X_full[:,  8]), np.real(X_full[:,  8]))
X_full_phase[:,  9] = np.arctan2(np.imag(X_full[:,  9]), np.real(X_full[:,  9]))
X_full_phase[:, 10] = np.arctan2(np.imag(X_full[:, 10]), np.real(X_full[:, 10]))

# =========================================================
#            FILTERING THE PHASE INFORMATION:             =
# =========================================================

upper_limit = np.max(X_full_abs)

threshold_actual = upper_limit * threshold_percentage

# =====================

binary_filter = np.zeros([8192, 11])

column_index = 0

for evaluation_number_2 in range (11) :
    
    row = 0
        
    for evaluation_number_1 in range (8192) :
        
        if X_full_abs[row, column_index] < threshold_actual :
            
            binary_filter[row, column_index] = 0
            
            row = row + 1
            
        elif X_full_abs[row, column_index] >= threshold_actual :
    
            binary_filter[row, column_index] = 1
            
            row = row + 1
            
    column_index = column_index + 1

# =====================

row = 0

binary_filter_mandate = np.zeros([8192, 1])

for evaluation_number in range (8192) :
    
    if sum(binary_filter[row, :]) > 0 :
        
        binary_filter_mandate[row, 0] = 1
        
        row = row + 1
        
    elif sum(binary_filter[row, :]) == 0 :
        
        binary_filter_mandate[row, 0] = 0
        
        row = row + 1

# =====================

phase_filtered = X_full_phase * binary_filter_mandate

# =====================

active = sum(binary_filter_mandate) / 8192

# =========================================================
#                   T-SCORE AMPLITUDE:                    =
# =========================================================

# =====================
#     HEALTHY SET:
# =====================

mean_vector_amplitude = np.zeros([8192, 1])

row = 0

for evaluation_number in range (8192) :
    
    mean_vector_amplitude[row, 0] = (1/6) * (X_full_abs[row, 0] +\
                                             X_full_abs[row, 1] +\
                                             X_full_abs[row, 2] +\
                                             X_full_abs[row, 3] +\
                                             X_full_abs[row, 4] +\
                                             X_full_abs[row, 5] )
    
    row = row + 1

# =====================
    
#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(freq, X_full_abs[:, 0:6], 'b', alpha = 0.05, linewidth = 0.8)
#plt.plot(freq, mean_vector_amplitude, 'k', alpha = 0.8, linewidth = 0.8, linestyle = '--')
#plt.plot(freq, X_full_abs[:, 6], 'r', alpha = 0.2, linewidth = 0.8)
#plt.xlim(100, 150)
#plt.ylim(0, 0.08)
#plt.show()

# =====================

sub_calc = np.zeros([8192, 6])

row = 0

for evaluation_number in range (8192) : 
    
    sub_calc[row, 0] = (X_full_abs[row, 0] - mean_vector_amplitude[row, 0])**2
    sub_calc[row, 1] = (X_full_abs[row, 1] - mean_vector_amplitude[row, 0])**2
    sub_calc[row, 2] = (X_full_abs[row, 2] - mean_vector_amplitude[row, 0])**2
    sub_calc[row, 3] = (X_full_abs[row, 3] - mean_vector_amplitude[row, 0])**2
    sub_calc[row, 4] = (X_full_abs[row, 4] - mean_vector_amplitude[row, 0])**2
    sub_calc[row, 5] = (X_full_abs[row, 5] - mean_vector_amplitude[row, 0])**2

    row = row + 1

# =====================

sigma_vector_amplitude = np.zeros([8192,1])

row = 0

for evaluation_number in range (8192) :
    
    sigma_vector_amplitude[row, 0] = np.sqrt( (1/6) * ( sub_calc[row, 0] + \
                                                        sub_calc[row, 1] + \
                                                        sub_calc[row, 2] + \
                                                        sub_calc[row, 3] + \
                                                        sub_calc[row, 4] + \
                                                        sub_calc[row, 5]     ) )

    row = row + 1

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(freq, sigma_vector_amplitude, 'b', alpha = 0.8, linewidth = 0.8)
#plt.plot(freq, mean_vector_amplitude, 'k', alpha = 0.8, linewidth = 0.8, linestyle = '--')
#plt.xlim(100, 200)
#plt.ylim(0, 0.2)
#plt.show()

# =====================

residual_deviation = np.zeros([8192, 6])

row = 0

for evaluation_number in range (8192) : 
    
    residual_deviation[row, 0] = np.sqrt( ( X_full_abs[row, 0] - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 1] = np.sqrt( ( X_full_abs[row, 1] - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 2] = np.sqrt( ( X_full_abs[row, 2] - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 3] = np.sqrt( ( X_full_abs[row, 3] - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 4] = np.sqrt( ( X_full_abs[row, 4] - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 5] = np.sqrt( ( X_full_abs[row, 5] - mean_vector_amplitude[row, 0] )**2 )

    row = row + 1

# =====================

#plt.figure(figsize = (12, 8), dpi = 1200)
#plt.plot(freq, sigma_vector_amplitude, 'k', alpha = 0.8, linewidth = 0.8, linestyle = '--')
#plt.xlim(275,300)
#plt.plot(freq, residual_deviation[:, :], 'b', alpha = 0.1, linewidth = 0.8)
#plt.ylim(0,0.001)
#plt.show()

# =====================

counter_amp = 0

sub_calc = np.zeros([8192, 6])

row = 0

for evaluation_number in range (8192) :
    
    if sigma_vector_amplitude[row, 0] > 0 :

        sub_calc[row, 0] = ( (residual_deviation[row, 0]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 1] = ( (residual_deviation[row, 1]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 2] = ( (residual_deviation[row, 2]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 3] = ( (residual_deviation[row, 3]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 4] = ( (residual_deviation[row, 4]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 5] = ( (residual_deviation[row, 5]) / sigma_vector_amplitude[row, 0] )**2
    
        row = row + 1
        
        counter_amp = counter_amp + 1

    
    else : 
        
        row = row + 1

comparison_amp = counter_amp / 8192

# =====================

T_score_trial_1_amp = np.sum(sub_calc[:, 0]) / (8192)
T_score_trial_2_amp = np.sum(sub_calc[:, 1]) / (8192)
T_score_trial_3_amp = np.sum(sub_calc[:, 2]) / (8192)
T_score_trial_4_amp = np.sum(sub_calc[:, 3]) / (8192)
T_score_trial_5_amp = np.sum(sub_calc[:, 4]) / (8192)
T_score_trial_6_amp = np.sum(sub_calc[:, 5]) / (8192)

# =====================
#     DAMAGED SET:
# =====================

residual_deviation = np.zeros([8192, 5])

row = 0

for evaluation_number in range (8192) : 
    
    residual_deviation[row, 0] = np.sqrt( ( X_full_abs[row, 6]  - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 1] = np.sqrt( ( X_full_abs[row, 7]  - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 2] = np.sqrt( ( X_full_abs[row, 8]  - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 3] = np.sqrt( ( X_full_abs[row, 9]  - mean_vector_amplitude[row, 0] )**2 )
    residual_deviation[row, 4] = np.sqrt( ( X_full_abs[row, 10] - mean_vector_amplitude[row, 0] )**2 )

    row = row + 1

# =====================

sub_calc = np.zeros([8192, 5])

row = 0

for evaluation_number in range (8192) :
    
    if sigma_vector_amplitude[row, 0] > 0 :
        
        sub_calc[row, 0] = ( (residual_deviation[row, 0]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 1] = ( (residual_deviation[row, 1]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 2] = ( (residual_deviation[row, 2]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 3] = ( (residual_deviation[row, 3]) / sigma_vector_amplitude[row, 0] )**2
        sub_calc[row, 4] = ( (residual_deviation[row, 4]) / sigma_vector_amplitude[row, 0] )**2
    
        row = row + 1


    else : 
        
        row = row + 1

# =====================

T_score_L1_amp = np.sum(sub_calc[:, 0]) / (8192)
T_score_L2_amp = np.sum(sub_calc[:, 1]) / (8192)
T_score_L3_amp = np.sum(sub_calc[:, 2]) / (8192)
T_score_L4_amp = np.sum(sub_calc[:, 3]) / (8192)
T_score_L5_amp = np.sum(sub_calc[:, 4]) / (8192)

# =====================

x_values_healthy_amp = np.arange(1, 7, 1)

x_values_damaged_amp = np.arange(1.5, 6.5, 1)

# =====================

y_values_healthy_amp = np.zeros([6, 1])

y_values_healthy_amp[0, 0] = T_score_trial_1_amp
y_values_healthy_amp[1, 0] = T_score_trial_2_amp
y_values_healthy_amp[2, 0] = T_score_trial_3_amp
y_values_healthy_amp[3, 0] = T_score_trial_4_amp
y_values_healthy_amp[4, 0] = T_score_trial_5_amp
y_values_healthy_amp[5, 0] = T_score_trial_6_amp

# =====================

y_values_damaged_amp = np.zeros([5, 1])

y_values_damaged_amp[0, 0] = T_score_L1_amp
y_values_damaged_amp[1, 0] = T_score_L2_amp
y_values_damaged_amp[2, 0] = T_score_L3_amp
y_values_damaged_amp[3, 0] = T_score_L4_amp
y_values_damaged_amp[4, 0] = T_score_L5_amp

# =====================

combined_array_amp = np.zeros([11, 1])

combined_array_amp[0:6] = y_values_healthy_amp

combined_array_amp[6:11] = y_values_damaged_amp

# =====================

y_upper_amp = 1.2*max(combined_array_amp)

# =====================

#plt.figure(figsize = (8, 6), dpi = 1200)

#plt.title('Excitation Frequency: 5 (Hz)                 Location: Landing Platform')

#plt.scatter(x_values_healthy_amp, y_values_healthy_amp, c = 'g', label = 'Healthy')
#plt.scatter(x_values_damaged_amp, y_values_damaged_amp, c = 'r', label = 'Damaged')

#plt.ylabel("Amplitude T-score")

#plt.text(x_values_healthy_amp[0], y_values_healthy_amp[0]-(0.038*y_upper_amp), "Trial 1: %.2f" % combined_array_amp[0, 0], fontsize=9, ha='center', va='top')           #don't mind me         
#plt.text(x_values_healthy_amp[1], y_values_healthy_amp[1]-(0.038*y_upper_amp), "Trial 2: %.2f" % combined_array_amp[1, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_amp[2], y_values_healthy_amp[2]-(0.038*y_upper_amp), "Trial 3: %.2f" % combined_array_amp[2, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_amp[3], y_values_healthy_amp[3]-(0.038*y_upper_amp), "Trial 4: %.2f" % combined_array_amp[3, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_amp[4], y_values_healthy_amp[4]-(0.038*y_upper_amp), "Trial 5: %.2f" % combined_array_amp[4, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_amp[5], y_values_healthy_amp[5]-(0.038*y_upper_amp), "Trial 6: %.2f" % combined_array_amp[5, 0], fontsize=9, ha='center', va='top')

#plt.text(x_values_damaged_amp[0], y_values_damaged_amp[0]-(0.038*y_upper_amp), "L1: %.2f" % combined_array_amp[6, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_amp[1], y_values_damaged_amp[1]-(0.038*y_upper_amp), "L2: %.2f" % combined_array_amp[7, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_amp[2], y_values_damaged_amp[2]-(0.038*y_upper_amp), "L3: %.2f" % combined_array_amp[8, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_amp[3], y_values_damaged_amp[3]-(0.038*y_upper_amp), "L4: %.2f" % combined_array_amp[9, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_amp[4], y_values_damaged_amp[4]-(0.038*y_upper_amp), "L5: %.2f" % combined_array_amp[10, 0], fontsize=9, ha='center', va='top')

#plt.ylim(-0.1*y_upper_amp, y_upper_amp)
#plt.xticks([])
#plt.legend()
#plt.legend(loc='upper right')

#plt.axhline(y = 1, color = 'black', linestyle = '--', linewidth = 1.0, alpha = 0.1)

#plt.axhline(y = y_values_healthy_amp[0, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_amp[1, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_amp[2, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_amp[3, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_amp[4, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_amp[5, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)

#plt.axhline(y = y_values_damaged_amp[0, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_amp[1, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_amp[2, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_amp[3, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_amp[4, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)

#plt.xlim(0.5, 6.5)

#plt.show()

# =========================================================
#                      T-SCORE PHASE:                     =
# =========================================================

mean_vector_phase = np.zeros([8192, 1])

row = 0

for evaluation_number in range (8192) :
    
    mean_vector_phase[row, 0] = (1/6) * (phase_filtered[row, 0] +\
                                         phase_filtered[row, 1] +\
                                         phase_filtered[row, 2] +\
                                         phase_filtered[row, 3] +\
                                         phase_filtered[row, 4] +\
                                         phase_filtered[row, 5] )
    
    row = row + 1

# =====================
    
#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(freq, phase_filtered[:, 0:6], 'b', alpha = 0.05, linewidth = 0.8)
#plt.plot(freq, mean_vector_phase, 'k', alpha = 0.8, linewidth = 0.8, linestyle = '--')
#plt.xlim(0, 50)
#plt.show()

# =====================

sub_calc = np.zeros([8192, 6])

row = 0

for evaluation_number in range (8192) : 
    
    sub_calc[row, 0] = (phase_filtered[row, 0] - mean_vector_phase[row, 0])**2
    sub_calc[row, 1] = (phase_filtered[row, 1] - mean_vector_phase[row, 0])**2
    sub_calc[row, 2] = (phase_filtered[row, 2] - mean_vector_phase[row, 0])**2
    sub_calc[row, 3] = (phase_filtered[row, 3] - mean_vector_phase[row, 0])**2
    sub_calc[row, 4] = (phase_filtered[row, 4] - mean_vector_phase[row, 0])**2
    sub_calc[row, 5] = (phase_filtered[row, 5] - mean_vector_phase[row, 0])**2

    row = row + 1

# =====================

sigma_vector_phase = np.zeros([8192,1])

row = 0

for evaluation_number in range(8192) :
    
    sigma_vector_phase[row, 0] = np.sqrt( (1/6) * ( sub_calc[row, 0] + \
                                                    sub_calc[row, 1] + \
                                                    sub_calc[row, 2] + \
                                                    sub_calc[row, 3] + \
                                                    sub_calc[row, 4] + \
                                                    sub_calc[row, 5]     ) )

    row = row + 1

# =====================

#plt.figure(figsize = (25, 6), dpi = 1200)
#plt.plot(freq, sigma_vector_phase, 'b', alpha = 0.8, linewidth = 0.8)
#plt.plot(freq, mean_vector_phase, 'k', alpha = 0.8, linewidth = 0.8, linestyle = '--')
#plt.xlim(0, 50)
#plt.show()

# =====================

residual_deviation = np.zeros([8192, 6])

row = 0

for evaluation_number in range (8192) : 
    
    residual_deviation[row, 0] = np.sqrt( ( phase_filtered[row, 0] - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 1] = np.sqrt( ( phase_filtered[row, 1] - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 2] = np.sqrt( ( phase_filtered[row, 2] - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 3] = np.sqrt( ( phase_filtered[row, 3] - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 4] = np.sqrt( ( phase_filtered[row, 4] - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 5] = np.sqrt( ( phase_filtered[row, 5] - mean_vector_phase[row, 0] )**2 )

    row = row + 1

# =====================

#plt.figure(figsize = (12, 8), dpi = 1200)
#plt.plot(freq, sigma_vector_phase, 'k', alpha = 0.8, linewidth = 0.8, linestyle = '--')
#plt.plot(freq, residual_deviation[:, 1], 'b', alpha = 0.8, linewidth = 0.8)
#plt.xlim(0,50)
#plt.show()

# =====================

counter = 0

sub_calc = np.zeros([8192, 6])

row = 0

for evaluation_number in range (8192) :
    
    if sigma_vector_phase[row, 0] > 0 :
        
        sub_calc[row, 0] = ( (residual_deviation[row, 0]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 1] = ( (residual_deviation[row, 1]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 2] = ( (residual_deviation[row, 2]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 3] = ( (residual_deviation[row, 3]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 4] = ( (residual_deviation[row, 4]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 5] = ( (residual_deviation[row, 5]) / sigma_vector_phase[row, 0] )**2
    
        row = row + 1
        
        counter = counter + 1

    
    else : 
        
        row = row + 1

comparison = counter / sum(binary_filter_mandate)

#check = sum(binary_filter_mandate)

# =====================

T_score_trial_1 = np.sum(sub_calc[:, 0]) / (8192 * active)
T_score_trial_2 = np.sum(sub_calc[:, 1]) / (8192 * active)
T_score_trial_3 = np.sum(sub_calc[:, 2]) / (8192 * active)
T_score_trial_4 = np.sum(sub_calc[:, 3]) / (8192 * active)
T_score_trial_5 = np.sum(sub_calc[:, 4]) / (8192 * active)
T_score_trial_6 = np.sum(sub_calc[:, 5]) / (8192 * active)
    
# =====================
#     DAMAGED SET:
# =====================

residual_deviation = np.zeros([8192, 5])

row = 0

for evaluation_number in range (8192) : 
    
    residual_deviation[row, 0] = np.sqrt( ( phase_filtered[row, 6]  - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 1] = np.sqrt( ( phase_filtered[row, 7]  - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 2] = np.sqrt( ( phase_filtered[row, 8]  - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 3] = np.sqrt( ( phase_filtered[row, 9]  - mean_vector_phase[row, 0] )**2 )
    residual_deviation[row, 4] = np.sqrt( ( phase_filtered[row, 10] - mean_vector_phase[row, 0] )**2 )

    row = row + 1

# =====================

sub_calc = np.zeros([8192, 5])

row = 0

for evaluation_number in range (8192) :
    
    if sigma_vector_phase[row, 0] > 0 :
        
        sub_calc[row, 0] = ( (residual_deviation[row, 0]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 1] = ( (residual_deviation[row, 1]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 2] = ( (residual_deviation[row, 2]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 3] = ( (residual_deviation[row, 3]) / sigma_vector_phase[row, 0] )**2
        sub_calc[row, 4] = ( (residual_deviation[row, 4]) / sigma_vector_phase[row, 0] )**2
    
        row = row + 1


    else : 
        
        row = row + 1

# =====================

T_score_L1 = np.sum(sub_calc[:, 0]) / (8192 * active)
T_score_L2 = np.sum(sub_calc[:, 1]) / (8192 * active)
T_score_L3 = np.sum(sub_calc[:, 2]) / (8192 * active)
T_score_L4 = np.sum(sub_calc[:, 3]) / (8192 * active)
T_score_L5 = np.sum(sub_calc[:, 4]) / (8192 * active)

# =====================

x_values_healthy_phase = np.arange(1, 7, 1)

x_values_damaged_phase = np.arange(1.5, 6.5, 1)

# =====================

y_values_healthy_phase = np.zeros([6, 1])

y_values_healthy_phase[0, 0] = T_score_trial_1[0]
y_values_healthy_phase[1, 0] = T_score_trial_2[0]
y_values_healthy_phase[2, 0] = T_score_trial_3[0]
y_values_healthy_phase[3, 0] = T_score_trial_4[0]
y_values_healthy_phase[4, 0] = T_score_trial_5[0]
y_values_healthy_phase[5, 0] = T_score_trial_6[0]

# =====================

y_values_damaged_phase = np.zeros([5, 1])

y_values_damaged_phase[0, 0] = T_score_L1[0]
y_values_damaged_phase[1, 0] = T_score_L2[0]
y_values_damaged_phase[2, 0] = T_score_L3[0]
y_values_damaged_phase[3, 0] = T_score_L4[0]
y_values_damaged_phase[4, 0] = T_score_L5[0]

# =====================

combined_array_phase = np.zeros([11, 1])

combined_array_phase[0:6] = y_values_healthy_phase

combined_array_phase[6:11] = y_values_damaged_phase

# =====================

y_upper = 1.2*max(combined_array_phase)

# =====================

#plt.figure(figsize = (8, 6), dpi = 1200)

#plt.title('Excitation Frequency: 5 (Hz)                 Location: Landing Platform')

#plt.scatter(x_values_healthy_phase, y_values_healthy_phase, c = 'g', label = 'Healthy')
#plt.scatter(x_values_damaged_phase, y_values_damaged_phase, c = 'r', label = 'Damaged')

#plt.ylabel("Phase T-score")

#plt.text(x_values_healthy_phase[0], y_values_healthy_phase[0]-(0.038*y_upper), "Trial 1: %.2f" % combined_array_phase[0, 0], fontsize=9, ha='center', va='top')           #don't mind me         
#plt.text(x_values_healthy_phase[1], y_values_healthy_phase[1]-(0.038*y_upper), "Trial 2: %.2f" % combined_array_phase[1, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_phase[2], y_values_healthy_phase[2]-(0.038*y_upper), "Trial 3: %.2f" % combined_array_phase[2, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_phase[3], y_values_healthy_phase[3]-(0.038*y_upper), "Trial 4: %.2f" % combined_array_phase[3, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_phase[4], y_values_healthy_phase[4]-(0.038*y_upper), "Trial 5: %.2f" % combined_array_phase[4, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_healthy_phase[5], y_values_healthy_phase[5]-(0.038*y_upper), "Trial 6: %.2f" % combined_array_phase[5, 0], fontsize=9, ha='center', va='top')

#plt.text(x_values_damaged_phase[0], y_values_damaged_phase[0]-(0.038*y_upper), "L1: %.2f" % combined_array_phase[6, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_phase[1], y_values_damaged_phase[1]-(0.038*y_upper), "L2: %.2f" % combined_array_phase[7, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_phase[2], y_values_damaged_phase[2]-(0.038*y_upper), "L3: %.2f" % combined_array_phase[8, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_phase[3], y_values_damaged_phase[3]-(0.038*y_upper), "L4: %.2f" % combined_array_phase[9, 0], fontsize=9, ha='center', va='top')
#plt.text(x_values_damaged_phase[4], y_values_damaged_phase[4]-(0.038*y_upper), "L5: %.2f" % combined_array_phase[10, 0], fontsize=9, ha='center', va='top')

#plt.ylim(-0.1*y_upper, y_upper)
#plt.xticks([])
#plt.legend()
#plt.legend(loc='upper right')

#plt.axhline(y = 1, color = 'black', linestyle = '--', linewidth = 1.0, alpha = 0.1)

#plt.axhline(y = y_values_healthy_phase[0, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_phase[1, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_phase[2, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_phase[3, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_phase[4, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_healthy_phase[5, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)

#plt.axhline(y = y_values_damaged_phase[0, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_phase[1, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_phase[2, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_phase[3, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
#plt.axhline(y = y_values_damaged_phase[4, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)

#plt.xlim(0.5, 6.5)

#plt.show()

# =========================================================
#                       COMBINED PLOT:                    =
# =========================================================

fig, axes = plt.subplots(1, 2, figsize=(16, 6), dpi=1200)

plt.subplots_adjust(wspace=0.15)  #default of approx. 0.2 – 0.3
# ========================

#Figure 1:

axes[0].scatter(x_values_healthy_amp, y_values_healthy_amp, c = 'g', label = 'Healthy')

axes[0].scatter(x_values_damaged_amp, y_values_damaged_amp, c = 'r', label = 'Damaged')

axes[0].set_ylabel("Amplitude T-score", fontsize=12, labelpad=12)

axes[0].text(x_values_healthy_amp[0], y_values_healthy_amp[0]-(0.038*y_upper_amp), "Trial 1: %.2f" % combined_array_amp[0, 0], fontsize=9, ha='center', va='top')           #don't mind me         
axes[0].text(x_values_healthy_amp[1], y_values_healthy_amp[1]-(0.038*y_upper_amp), "Trial 2: %.2f" % combined_array_amp[1, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_healthy_amp[2], y_values_healthy_amp[2]-(0.038*y_upper_amp), "Trial 3: %.2f" % combined_array_amp[2, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_healthy_amp[3], y_values_healthy_amp[3]-(0.038*y_upper_amp), "Trial 4: %.2f" % combined_array_amp[3, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_healthy_amp[4], y_values_healthy_amp[4]-(0.038*y_upper_amp), "Trial 5: %.2f" % combined_array_amp[4, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_healthy_amp[5], y_values_healthy_amp[5]-(0.038*y_upper_amp), "Trial 6: %.2f" % combined_array_amp[5, 0], fontsize=9, ha='center', va='top')

axes[0].text(x_values_damaged_amp[0], y_values_damaged_amp[0]-(0.038*y_upper_amp), "L1: %.2f" % combined_array_amp[6, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_damaged_amp[1], y_values_damaged_amp[1]-(0.038*y_upper_amp), "L2: %.2f" % combined_array_amp[7, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_damaged_amp[2], y_values_damaged_amp[2]-(0.038*y_upper_amp), "L3: %.2f" % combined_array_amp[8, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_damaged_amp[3], y_values_damaged_amp[3]-(0.038*y_upper_amp), "L4: %.2f" % combined_array_amp[9, 0], fontsize=9, ha='center', va='top')
axes[0].text(x_values_damaged_amp[4], y_values_damaged_amp[4]-(0.038*y_upper_amp), "L5: %.2f" % combined_array_amp[10, 0], fontsize=9, ha='center', va='top')

axes[0].set_ylim(-0.1*y_upper_amp, y_upper_amp)
axes[0].set_xticks([])

axes[0].legend()
axes[0].legend(loc='upper right')

axes[0].axhline(y = 1, color = 'black', linestyle = '--', linewidth = 1.0, alpha = 0.1)

axes[0].axhline(y = y_values_healthy_amp[0, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_healthy_amp[1, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_healthy_amp[2, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_healthy_amp[3, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_healthy_amp[4, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_healthy_amp[5, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)

axes[0].axhline(y = y_values_damaged_amp[0, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_damaged_amp[1, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_damaged_amp[2, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_damaged_amp[3, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[0].axhline(y = y_values_damaged_amp[4, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)

axes[0].set_xlim(0.5, 6.5)

# ========================

#Figure 2:

axes[1].scatter(x_values_healthy_phase, y_values_healthy_phase, c = 'g', label = 'Healthy')

axes[1].scatter(x_values_damaged_phase, y_values_damaged_phase, c = 'r', label = 'Damaged')

axes[1].set_ylabel("Phase T-score", fontsize=12, labelpad=12)

axes[1].text(x_values_healthy_phase[0], y_values_healthy_phase[0]-(0.038*y_upper), "Trial 1: %.2f" % combined_array_phase[0, 0], fontsize=9, ha='center', va='top')           #don't mind me         
axes[1].text(x_values_healthy_phase[1], y_values_healthy_phase[1]-(0.038*y_upper), "Trial 2: %.2f" % combined_array_phase[1, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_healthy_phase[2], y_values_healthy_phase[2]-(0.038*y_upper), "Trial 3: %.2f" % combined_array_phase[2, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_healthy_phase[3], y_values_healthy_phase[3]-(0.038*y_upper), "Trial 4: %.2f" % combined_array_phase[3, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_healthy_phase[4], y_values_healthy_phase[4]-(0.038*y_upper), "Trial 5: %.2f" % combined_array_phase[4, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_healthy_phase[5], y_values_healthy_phase[5]-(0.038*y_upper), "Trial 6: %.2f" % combined_array_phase[5, 0], fontsize=9, ha='center', va='top')

axes[1].text(x_values_damaged_phase[0], y_values_damaged_phase[0]-(0.038*y_upper), "L1: %.2f" % combined_array_phase[6, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_damaged_phase[1], y_values_damaged_phase[1]-(0.038*y_upper), "L2: %.2f" % combined_array_phase[7, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_damaged_phase[2], y_values_damaged_phase[2]-(0.038*y_upper), "L3: %.2f" % combined_array_phase[8, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_damaged_phase[3], y_values_damaged_phase[3]-(0.038*y_upper), "L4: %.2f" % combined_array_phase[9, 0], fontsize=9, ha='center', va='top')
axes[1].text(x_values_damaged_phase[4], y_values_damaged_phase[4]-(0.038*y_upper), "L5: %.2f" % combined_array_phase[10, 0], fontsize=9, ha='center', va='top')

axes[1].set_ylim(-0.1*y_upper, y_upper)
axes[1].set_xticks([])

axes[1].legend()
axes[1].legend(loc='upper right')

axes[1].axhline(y = 1, color = 'black', linestyle = '--', linewidth = 1.0, alpha = 0.1)

axes[1].axhline(y = y_values_healthy_phase[0, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_healthy_phase[1, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_healthy_phase[2, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_healthy_phase[3, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_healthy_phase[4, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_healthy_phase[5, 0], color = 'green', linestyle = '-', linewidth = 0.1, alpha = 0.7)

axes[1].axhline(y = y_values_damaged_phase[0, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_damaged_phase[1, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_damaged_phase[2, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_damaged_phase[3, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)
axes[1].axhline(y = y_values_damaged_phase[4, 0], color = 'red', linestyle = '-', linewidth = 0.1, alpha = 0.7)

axes[1].set_xlim(0.5, 6.5)

# ========================

fig.suptitle('   Excitation Frequency: 5 (Hz)                                      Location: Landing Platform                 Threshold Amplitude for Phase Analysis: 1%', fontsize=12, y=0.92)

# ========================

plt.show()

# =========================================================






