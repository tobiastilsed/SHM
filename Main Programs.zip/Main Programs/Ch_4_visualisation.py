

# =====================
import numpy as np
# =====================
from scipy.optimize import curve_fit
# =====================
import matplotlib.pyplot as plt
# =====================
import matplotlib.image as mpimg
# =====================
from trial_solver import trial_function
# =====================


# ==========================================
#   MODULATE THE TWO BELOW - EVERYTHING    =
#            ELSE IS AUTOMATED:            =
# ==========================================

excitation_frequency = 10    # (Hz)

# =====================

accelerometer_channel = 2   # 2 = Nacelle
                            # 3 = Landing Platform

# ==========================================

img = mpimg.imread('test matrices.png')
fig = plt.figure(dpi=1200)
plt.imshow(img)
plt.axis('off')
plt.show()

# =====================

trial_1, trial_2, trial_3, trial_4, trial_5, trial_6, L1, L2, L3, L4, L5 = trial_function(excitation_frequency)      #don't mind me    

# =====================

x_full = np.zeros([25000, 11])

# =====================

column_index = accelerometer_channel

# =====================

x_full[:, 0]  = trial_1[:, column_index]
x_full[:, 1]  = trial_2[:, column_index]
x_full[:, 2]  = trial_3[:, column_index]
x_full[:, 3]  = trial_4[:, column_index]
x_full[:, 4]  = trial_5[:, column_index]
x_full[:, 5]  = trial_6[:, column_index]
x_full[:, 6]  =      L1[:, column_index]
x_full[:, 7]  =      L2[:, column_index]
x_full[:, 8]  =      L3[:, column_index]
x_full[:, 9]  =      L4[:, column_index]
x_full[:, 10] =      L5[:, column_index]

# =====================

x_full_sync = np.zeros([25000, 11])

# =====================

x_full_sync[:, 0]  = trial_1[:, 3]
x_full_sync[:, 1]  = trial_2[:, 3]
x_full_sync[:, 2]  = trial_3[:, 3]
x_full_sync[:, 3]  = trial_4[:, 3]
x_full_sync[:, 4]  = trial_5[:, 3]
x_full_sync[:, 5]  = trial_6[:, 3]
x_full_sync[:, 6]  =      L1[:, 3]
x_full_sync[:, 7]  =      L2[:, 3]
x_full_sync[:, 8]  =      L3[:, 3]
x_full_sync[:, 9]  =      L4[:, 3]
x_full_sync[:, 10] =      L5[:, 3]

# =====================

if column_index == 2 :
    
    location_tag = "Nacelle"
    
if column_index == 3 :
    
    location_tag = "Landing Platform"

# =========================================================
# ================= CHECKING DIVISIBILITY: ================
# =========================================================

if 5000 % excitation_frequency != 0 :
    
    remainder = round(((5000 % excitation_frequency) / excitation_frequency)**-1) - 1

    print("The sample rate and excitation")
    print("frequency aren't playing nice ")
    print("together - we're going to have")
    print("to skip:                      ")
    print("                              ")
    print("          %.0f cycles" % remainder)
    print("                              ")
    print(" ...between each visualised"   )
    print("  and evaluated cycle for"     )
    print("      proper alignment."       )
    print("\n-----------------------------\n")
    
else :
        
    remainder = 0

# =========================================================
# =================== ALIGNING THE SETS ===================
# =========================================================

full = 5000 // (1 * excitation_frequency)

full_float = 5000 / excitation_frequency

# =====================

#ten_cycles = 10 * full

necessary_cycles = round((remainder + 1) * 10 * full_float)

# =====================

half = 5000 // (2 * excitation_frequency)

half_float = 5000 / (2 * excitation_frequency)

# =====================

three_quarter = (3 * 5000) // (4 * excitation_frequency)
  
three_quarter_float = (3 * 5000) / (4 * excitation_frequency)

# =====================

x_aligned_full = np.zeros([necessary_cycles, 11])

sin_aligned_full = np.zeros([necessary_cycles, 11])

# =========================================================
# ============ TEMPORAL ALIGNMENT FOR LOOP: ===============
# =========================================================

for trial_index in range (11) :

    # =====================
    
    x_local_sync = x_full_sync[:, trial_index]
    
    x_local = x_full[:, trial_index]

    # =====================
    
    t = np.arange(0, 5, 0.0002)  

    # ==========================================
    # ============ fitting function: ===========
    # ==========================================
    
    t_fitted = t
    
    y = x_local_sync
    
    # =====================
    
    initial_guess = [1.3, excitation_frequency, 0.0, 0.0]
    
    # =====================
    
    def sine_func(t_fitted, A, f, phi, offset) :
        
        return A * np.sin(2 * np.pi * f * t_fitted + phi) + offset

    # =====================
    
    params, _ = curve_fit(sine_func, t_fitted, y, p0=initial_guess)
    
    A_fit, f_fit, phi_fit, offset_fit = params
    
    x_fitted = sine_func(t_fitted, A_fit, f_fit, phi_fit, offset_fit)
    
    # =====================
    
    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.plot(t_fitted, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

    # ==========================================
    # ============= ascending case =============
    # ==========================================
    
    if x_fitted[1] > x_fitted[0] :         
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # ==========================================
    # ============ descending case =============
    # ==========================================
    
    elif x_fitted[1] < x_fitted[0] :
        
        x_local = x_local[half:]
        
        x_fitted = x_fitted[half:]
        
    # =====================
        
        counter_1 = 0
        
        for evaluation_number in range(25000) :
            
            if x_fitted[counter_1 + 1] > x_fitted[counter_1] :
                
                counter_1 = counter_1 + 1
                
            else :
                
                break
    
    # =====================
    
    C = counter_1 + three_quarter         #preferred this location aesthetically
    
    # =====================
    
    x_local = x_local[C:]                 #slicing from preferred location
    
    x_fitted = x_fitted[C:]               #slicing from preferred location
    
    # =====================
    
    x_local = x_local[:necessary_cycles]                #slicing up to ten cycles [or that which facilitates a coherent mapping of ten]
    
    x_fitted = x_fitted[:necessary_cycles]              #slicing up to ten cycles [or that which facilitates a coherent mapping of ten]
    
    # =====================

    x_aligned_full[:, trial_index] = x_local
    
    sin_aligned_full[:, trial_index] = x_fitted
    
    t = t[:necessary_cycles]                            

    # =====================

    #plt.figure(figsize = (25, 6), dpi = 300)
    #plt.plot(t, x_fitted, 'r', alpha = 0.2, linewidth = 2.0)
    #plt.plot(t, x_local, 'y', alpha = 0.3, linewidth = 2.0)
    #plt.ylabel('Amplitude (m/s²)')
    #plt.ylim(-1.8, 1.8)
    #plt.show()

# =========================================================
# =================== SLICING THE SETS: ===================
# =========================================================

t = t[:full]

# =====================


trial_1_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_1_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 0]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1


# =====================


trial_2_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_2_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 1]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_3_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_3_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 2]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_4_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_4_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 3]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_5_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_5_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 4]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


trial_6_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    trial_6_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 5]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================


L1_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L1_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 6]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L2_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L2_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 7]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L3_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L3_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 8]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L4_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L4_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 9]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# =====================

L5_sliced = np.zeros([full, 10])

sample_index = 0

column_index = 0

for evaluation_number in range (10) :
    
    L5_sliced[:, column_index] = x_aligned_full[sample_index:sample_index + full, 10]
    
    sample_index = sample_index + round((remainder+1)*full_float)
    
    column_index = column_index + 1

# ===========================================
# =================== L1: ===================
# ===========================================

plt.figure(figsize = (16, 6), dpi = 1200)

plt.plot(t, trial_1_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_2_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_3_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_4_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_5_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_6_sliced, 'g', alpha = 0.4, linewidth = 0.2)

plt.plot(t, L1_sliced, 'r', alpha = 0.4, linewidth = 0.2)

plt.title('Excitation Frequency: %.0f (Hz)                Location: %s' % (excitation_frequency, location_tag), fontsize = 12)

plt.plot(0, 0, color='g', alpha = 0.8, linewidth = 1.0, label = 'Healthy [60 cycles]')
plt.plot(0, 0, color='r', alpha = 0.5, linewidth = 1.0, label = 'L1 [10 cycles]')

plt.ylim(-2, 2)

plt.xlabel('Unified Time (s)', fontsize = 12)

plt.ylabel('Acceleration (m/s²)', fontsize = 12)

plt.legend(loc = 'upper right', fontsize = 12)

plt.show()

# ===========================================
# =================== L2: ===================
# ===========================================

plt.figure(figsize = (16, 6), dpi = 1200)

plt.plot(t, trial_1_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_2_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_3_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_4_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_5_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_6_sliced, 'g', alpha = 0.4, linewidth = 0.2)

plt.plot(t, L2_sliced, 'r', alpha = 0.4, linewidth = 0.2)

plt.title('Excitation Frequency: %.0f (Hz)                Location: %s' % (excitation_frequency, location_tag), fontsize = 12)

plt.plot(0, 0, color='g', alpha = 0.8, linewidth = 1.0, label = 'Healthy [60 cycles]')
plt.plot(0, 0, color='r', alpha = 0.5, linewidth = 1.0, label = 'L2 [10 cycles]')

plt.ylim(-2, 2)

plt.xlabel('Unified Time (s)', fontsize = 12)

plt.ylabel('Acceleration (m/s²)', fontsize = 12)

plt.legend(loc = 'upper right', fontsize = 12)

plt.show()

# ===========================================
# =================== L3: ===================
# ===========================================

plt.figure(figsize = (16, 6), dpi = 1200)

plt.plot(t, trial_1_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_2_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_3_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_4_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_5_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_6_sliced, 'g', alpha = 0.4, linewidth = 0.2)

plt.plot(t, L3_sliced, 'r', alpha = 0.4, linewidth = 0.2)

plt.title('Excitation Frequency: %.0f (Hz)                Location: %s' % (excitation_frequency, location_tag), fontsize = 12)

plt.plot(0, 0, color='g', alpha = 0.8, linewidth = 1.0, label = 'Healthy [60 cycles]')
plt.plot(0, 0, color='r', alpha = 0.5, linewidth = 1.0, label = 'L3 [10 cycles]')

plt.ylim(-2, 2)

plt.xlabel('Unified Time (s)', fontsize = 12)

plt.ylabel('Acceleration (m/s²)', fontsize = 12)

plt.legend(loc = 'upper right', fontsize = 12)

plt.show()

# ===========================================
# =================== L4: ===================
# ===========================================

plt.figure(figsize = (16, 6), dpi = 1200)

plt.plot(t, trial_1_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_2_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_3_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_4_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_5_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_6_sliced, 'g', alpha = 0.4, linewidth = 0.2)

plt.plot(t, L4_sliced, 'r', alpha = 0.4, linewidth = 0.2)

plt.title('Excitation Frequency: %.0f (Hz)                Location: %s' % (excitation_frequency, location_tag), fontsize = 12)

plt.plot(0, 0, color='g', alpha = 0.8, linewidth = 1.0, label = 'Healthy [60 cycles]')
plt.plot(0, 0, color='r', alpha = 0.5, linewidth = 1.0, label = 'L4 [10 cycles]')

plt.ylim(-2, 2)

plt.xlabel('Unified Time (s)', fontsize = 12)

plt.ylabel('Acceleration (m/s²)', fontsize = 12)

plt.legend(loc = 'upper right', fontsize = 12)

plt.show()

# ===========================================
# =================== L5: ===================
# ===========================================

plt.figure(figsize = (16, 6), dpi = 1200)

plt.plot(t, trial_1_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_2_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_3_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_4_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_5_sliced, 'g', alpha = 0.4, linewidth = 0.2)
plt.plot(t, trial_6_sliced, 'g', alpha = 0.4, linewidth = 0.2)

plt.plot(t, L5_sliced, 'r', alpha = 0.4, linewidth = 0.2)

plt.title('Excitation Frequency: %.0f (Hz)                Location: %s' % (excitation_frequency, location_tag), fontsize = 12)

plt.plot(0, 0, color='g', alpha = 0.8, linewidth = 1.0, label = 'Healthy [60 cycles]')
plt.plot(0, 0, color='r', alpha = 0.5, linewidth = 1.0, label = 'L5 [10 cycles]')

plt.ylim(-2, 2)

plt.xlabel('Unified Time (s)', fontsize = 12)

plt.ylabel('Acceleration (m/s²)', fontsize = 12)

plt.legend(loc = 'upper right', fontsize = 12)

plt.show()

# ===========================================




